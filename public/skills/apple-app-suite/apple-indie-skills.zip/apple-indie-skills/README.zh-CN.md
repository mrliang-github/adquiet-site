# Apple 独立开发上架与出图 Skill 套件（良逍出品）

这是一套在多款真实过审 App 开发过程中沉淀下来的 Agent Skills 组合，覆盖 **原生界面审查 → 商店宣传图策划与生成 → 送审前合规预检 → 多地区上架核对** 四个关键环节。

## 包含的 5 个子 Skill

1. **`apple-native-ui`**：iOS / watchOS 原生界面与交互审查，把页面任务落实为可核验的布局、字级与状态反馈。
2. **`apple-image`（宣传图策划 Director）**：从真实代码与功能事实出发提炼卖点，强制隔离「内部说明」与「上图文案（Public Copy）」，防止模型把制作备注印进截图。
3. **`apple-image-studio`（宣传图生成 Studio）**：承接 `apple-image` 的交接契约，结合真实 UI 截图与机框素材生成成片（需宿主具备图像生成与看图工具）。
4. **`apple-app-review-audit`（送审预检）**：以 Apple 审核员视角只读排查二进制、隐私声明、内购恢复购买与文案宣传一致性。
5. **`app-store-release`（上架词覆盖与发布核对）**：核对目标地区、ASO 主攻词字段映射、截图与版本证据。

## 安装方式

将解压后的 5 个子目录复制到你的 Agent 技能目录即可：

- **Claude Code**：`~/.claude/skills/`
- **Codex**：`~/.codex/skills/`
- **通用 Agents / Antigravity**：`~/.agents/skills/`

## 使用前提与边界说明

- `apple-image` 不内置 Apple 官方机框 PNG（请从 Apple Design Resources 下载后放入 `apple-image/assets/device-frames/`）。
- `apple-image-studio` 需要你的 Agent 环境支持图像生成工具（如 `image_gen`）与图片查看工具（`view_image`）。
- `apple-app-review-audit` 默认只读检查，属于开发自查辅助，不替代 Apple 官方审核结论。

更多独立开发与 AI 工作流实战拆解，欢迎关注微信公众号：**良逍Ai出海笔记**（https://liangxiaoai.dev）。
