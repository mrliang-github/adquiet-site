---
name: apple-app-review-audit
description: "审核 iOS/iPadOS App 上架准备、拒审原因与重提方案，核对当前 Apple 官方要求。"
---

# Apple App Review Audit

Audit an iOS or iPadOS submission as a reviewer would encounter it. Apple review risk lives across the binary, runtime behavior, product claims, privacy disclosures, purchases, reviewer access, and App Store Connect state. A green build or a clean code diff proves only one part.

This skill is an internal preflight based on Apple public documentation. It cannot guarantee approval and must not be represented as Apple certification or legal advice.

## Default operating mode

- Work read-only unless the user explicitly asks for fixes.
- Do not submit a build, change App Store Connect, edit metadata, use credentials, contact Apple, or reply to App Review without explicit authorization.
- Do not use any personal credential manager unless the user explicitly requests it.
- Never print tokens, private keys, JWTs, provisioning contents, or secret values.
- Before inspecting a repository, read its `AGENTS.md` or equivalent instructions and run `git status --short --branch`.
- Preserve unrelated dirty and untracked files.
- Treat marketing text, screenshots, old reports, and product names as claims to verify, not as sources of truth.

## Supported scope

Primary scope:

- iOS and iPadOS App Store submissions
- New apps, updates, rejected submissions, and resubmissions
- Native Swift/Objective-C, Flutter, React Native, and hybrid apps

Route rather than mis-audit:

- Mac App Store: say the current skill has only partial coverage and identify the missing macOS-specific checks.
- Developer ID direct distribution: return `NOT_APPLICABLE` and recommend notarization, Hardened Runtime, signing, and Gatekeeper validation.
- TestFlight-only review: identify it as Beta App Review and adjust the submission-state checks.
- Alternative marketplaces or EU alternative terms: state that separate contractual and notarization rules apply.

## Required references

Read these files before auditing:

1. `references/apple-source-map.md`
2. `references/product-classification.md`
3. `references/scenario-modules.md`
4. `references/report-template.md`

Use `scripts/inspect_apple_project.sh <repo-root>` for the initial read-only capability scan when shell access is available. The script is evidence discovery, not a verdict generator.

## Workflow

### 1. Establish the exact target

Identify:

- repository root and active branch
- app target, platform, and distribution channel
- version and build being considered
- whether this is a new submission, update, rejection, or resubmission
- prior App Review messages and referenced guideline numbers, if available
- which App Store Connect app/version/build is in scope, if live access is authorized

If the workspace contains multiple apps, do not guess. Resolve the target from repository context or ask for the exact product.

### 2. Refresh Apple official sources

Open the live Apple pages required by `references/apple-source-map.md`.

At minimum, refresh:

- App Review Guidelines
- Upcoming Requirements
- App Store Connect submission/status documentation
- Human Interface Guidelines

Then open only the official scenario sources relevant to the product profile.

Record:

- retrieval date
- page title and URL
- visible Apple “last updated” date when present
- relevant guideline or requirement identifier

Use Apple primary sources for compliance claims. Third-party articles, competitor apps, open-source projects, and design galleries may inform examples or visual benchmarking, but they are not compliance authority.

If live official sources cannot be reached:

- mark the source snapshot `STALE_UNVERIFIED`
- do not issue a full `PASS`
- state which rules could not be refreshed

### 3. Build a product fingerprint

Classify the product from evidence, not naming.

Collect:

- primary user job and actual core loop
- intended audience and age range
- content origin: bundled, licensed, user-imported, generated, or user-generated
- accounts, login providers, guest accounts, and deletion behavior
- monetization: free, paid, non-consumable, consumable, subscription, ads, or external purchase
- data collected, transmitted, linked, tracked, or kept only on device
- permissions and protected resources
- backend and third-party SDKs
- AI inference, AI-generated content, or AI-assisted decisions
- regulated claims: health, medical, financial, gambling, children, safety, or diagnostics
- hardware, BLE, local network, VPN, location, background, or restricted entitlements
- destructive actions such as deleting photos, files, accounts, or records

Use `references/product-classification.md` to produce the fingerprint and activate scenario modules.

Name-based traps to avoid:

- “Coin” does not prove cryptocurrency or trading.
- “Doctor,” “health,” or “heat” does not prove a medical product.
- “Lie detector” may be entertainment, but every user-facing claim must make that boundary real.
- A photo app is not necessarily cloud-based; confirm whether media leaves the device.

### 4. Select audit modules

Always activate:

- Core App Review
- Design and Accessibility
- Privacy and Data Truth
- Runtime Reviewer Journey
- Packaging and Submission State
- Metadata and Claim Consistency

Activate conditional modules only when supported by evidence:

- Accounts and Sign in with Apple
- In-App Purchase and Subscriptions
- Health, Fitness, and Medical
- Photos, Video, Camera, Microphone, and Files
- Generative AI and Model-Produced Content
- User-Generated or Creator Content
- Kids, Teens, and Age Rating
- Games, Contests, Gambling, and Randomized Rewards
- Finance, Cryptocurrency, and Money Management
- Reader Apps, Imported Content, and Intellectual Property
- Location, Maps, Local Network, VPN, and Diagnostics
- Hardware, Bluetooth, and Companion Devices
- Ads, Tracking, Analytics, and Third-Party SDKs

List activated and explicitly excluded modules in the report.

### 5. Build the evidence chain

Inspect in this order:

1. **Repository truth**
   - project type and targets
   - `Info.plist`, entitlements, privacy manifests, SDKs, permission strings
   - purchase, account, deletion, content, data, and claim implementations
   - privacy policy, support URL, terms, review notes, metadata, and release docs

2. **Packaging truth**
   - current Apple SDK/Xcode requirement
   - Release configuration, archive/export, signing, bundle ID, version/build
   - privacy report and manifest validity
   - prohibited debug or development entitlements

3. **Runtime truth**
   - first launch and core task
   - permission denied, limited permission, no network, empty data, and failure states
   - login/demo access
   - paywall, purchase, restore, entitlement refresh, and cancellation paths
   - destructive actions and recovery
   - accessibility, Dynamic Type, contrast, labels, reduced motion, orientation, and device-size behavior

4. **Store truth**
   - app name, subtitle, description, keywords, category, age rating
   - screenshots and previews
   - privacy label and privacy-policy URL
   - content rights, encryption, ads/IDFA, availability, pricing
   - review contact, demo credentials, and review notes
   - app version, build, IAP/subscription, and submission states

5. **Review history**
   - exact Apple message
   - exact build reviewed
   - claimed remediation
   - evidence that the remediation exists in the new build and reviewer path

Prefer XcodeBuildMCP for Apple build and simulator work when available. Follow its required defaults check before the first build/run/test. Otherwise use the project’s established build commands.

The active user/project managed-workflow rules take precedence over this tool preference. When required, use the configured workflow-runner for builds, tests and installation; do not bypass it through raw XcodeBuildMCP build commands.

### 6. Audit the truth matrix

For every material feature or claim, compare:

| Surface | Question |
|---|---|
| Code/package | Does the submitted binary contain and support it? |
| Runtime | Can a reviewer reach it and does it behave as claimed? |
| Metadata/screenshots | Is it described accurately without exaggeration? |
| Privacy | Are collection, transmission, linking, and tracking disclosed consistently? |
| Purchases | Is the paid boundary visible, functional, restorable, and submitted? |
| Review notes | Are special setup, demo access, hardware, and non-obvious behavior explained? |

Any contradiction is a finding even if each surface looks reasonable in isolation.

### 6a. Verify research and keyword coverage for submission readiness

For every App Store submission-readiness assessment, also use [research and field coverage](../app-store-release/references/research-and-coverage.md) and sections A–B of the [shared preflight checklist](../app-store-release/references/preflight-checklist.md). Recover existing research and later product decisions, confirm storefronts/locales, and link each priority query to its product evidence and exact metadata field. Reuse still-applicable evidence for unchanged updates.

Report this separately from Apple rule compliance: `READY`, `NEEDS_WORK`, or `NOT_IN_SCOPE` with a reason. This is the user's release-process requirement, not an invented Apple rejection rule. Missing quantified search volume alone does not prevent a grounded first iteration; missing intent/coverage work prevents an overall submission-ready claim. A narrowly requested rejection diagnosis may leave this outside scope, but must not imply the entire release is ready.

### 7. Run the reviewer journey

Test the shortest realistic path an Apple reviewer will take:

- install or clean launch
- understand the product without private context
- grant, deny, or limit permissions
- reach the core value
- encounter paid functionality
- trigger quota-exhausted, product-unavailable, and entitlement-loading states; flag any gated action that silently no-ops
- access restore purchase and account deletion when applicable
- recover from backend, content, or device limitations

If a critical path cannot be exercised, do not infer that it works. Mark it `UNKNOWN` and explain what evidence is missing.

### 8. Classify findings

Use these severities:

- `BLOCKER`: a current Apple requirement is violated, a mandatory item is missing, the submitted experience is broken, or critical evidence is unavailable.
- `HIGH`: strong rejection risk or a material mismatch that should be fixed before submission.
- `MEDIUM`: design, clarity, resilience, or documentation issue that may delay review or confuse users.
- `LOW`: polish or maintainability issue with little direct review risk.

Use these evidence labels:

- `VERIFIED`: observed in current code, package, runtime, official backend, or official Apple source.
- `INFERRED`: supported by partial evidence but not directly observed.
- `UNKNOWN`: not accessible or not tested.
- `STALE`: based on an older artifact or unrefreshed source.

Do not convert inference into fact.

### 9. Decide the verdict

- `PASS`: no unresolved blockers/high findings; official sources refreshed; current Release build/package, critical runtime path, metadata/privacy, and submission state were verified.
- `PASS_WITH_RISKS`: no known blocker, but medium risks or non-critical unknowns remain.
- `BLOCKED`: a blocker/high-risk inconsistency remains, or required evidence is missing for a safe submission decision.
- `NOT_APPLICABLE`: the product is outside this skill’s distribution scope.

Passing this audit does not guarantee Apple approval.

### 10. Produce the report

Follow `references/report-template.md`.

Every blocker or high finding must contain:

- exact current Apple rule or official requirement
- official source link
- current product evidence
- user/reviewer impact
- smallest safe fix
- exact re-verification method

For rejected apps, include:

- rejection-to-remediation matrix
- draft review-note response grounded in evidence
- whether a new build is required or metadata-only remediation may be enough
- resubmission-state checks

Do not modify or submit anything unless the user separately authorizes implementation or submission.

## Completion status

End with one of:

- `DONE`: audit completed with sufficient evidence
- `DONE_WITH_CONCERNS`: audit completed but limitations remain
- `NEEDS_CONTEXT`: exact app or required evidence is missing
- `BLOCKED`: tools, access, build, or runtime prevented a meaningful audit
