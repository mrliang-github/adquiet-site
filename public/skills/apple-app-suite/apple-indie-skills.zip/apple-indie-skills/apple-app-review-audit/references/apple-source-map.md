# Apple Official Source Map

Use this as a routing index, not as a frozen copy of Apple policy. Refresh live pages for every release audit because guidelines, SDK requirements, age ratings, regional terms, and App Store Connect workflows change.

Snapshot checked: 2026-07-18.

## Always refresh

| Source | URL | Audit use |
|---|---|---|
| App Review Guidelines | https://developer.apple.com/app-store/review/guidelines/ | Current review rules and guideline identifiers |
| App Review overview | https://developer.apple.com/app-store/review/ | Review preparation, common issues, contact, appeals |
| Human Interface Guidelines | https://developer.apple.com/design/human-interface-guidelines | Design and interaction baseline |
| Upcoming Requirements | https://developer.apple.com/news/upcoming-requirements/ | Current SDK, Xcode, age-rating, and submission deadlines |
| Submit an app | https://developer.apple.com/help/app-store-connect/manage-submissions-to-app-review/submit-an-app | Current submission workflow |
| App and submission statuses | https://developer.apple.com/help/app-store-connect/reference/app-information/app-and-submission-statuses | Meaning of version, item, and submission states |
| Unresolved issues | https://developer.apple.com/help/app-store-connect/manage-submissions-to-app-review/manage-a-submission-with-unresolved-issues | Rejected-item edit/remove/resubmit workflow |

At the start of the report, record the retrieval date and any visible “Last Updated” date.

## Privacy and data

| Source | URL | Activate when |
|---|---|---|
| App Privacy Details | https://developer.apple.com/app-store/app-privacy-details/ | Every App Store submission |
| Manage app privacy | https://developer.apple.com/help/app-store-connect/manage-app-information/manage-app-privacy | Comparing App Store Connect answers with behavior |
| Privacy manifest files | https://developer.apple.com/documentation/bundleresources/privacy-manifest-files | App or SDK uses collected-data declarations or required-reason APIs |
| Add a privacy manifest | https://developer.apple.com/documentation/bundleresources/adding-a-privacy-manifest-to-your-app-or-third-party-sdk | Manifest location, validity, and SDK requirements |
| Describing data use | https://developer.apple.com/documentation/bundleresources/describing-data-use-in-privacy-manifests | Mapping collected data to manifest entries |

## Accounts and purchases

| Source | URL | Activate when |
|---|---|---|
| Offering account deletion | https://developer.apple.com/support/offering-account-deletion-in-your-app | Any account creation, including automatic guest accounts |
| Handling account deletion and Apple tokens | https://developer.apple.com/documentation/technotes/tn3194-handling-account-deletions-and-revoking-tokens-for-sign-in-with-apple | Sign in with Apple and account deletion |
| Managing accounts HIG | https://developer.apple.com/design/human-interface-guidelines/managing-accounts | Account creation, sign-in, deletion, and user control |
| In-App Purchase | https://developer.apple.com/in-app-purchase/ | Digital goods, unlocks, subscriptions, credits |
| Restoring purchased products | https://developer.apple.com/documentation/storekit/restoring-purchased-products | Restorable purchases |

## Product scenarios

| Source | URL | Activate when |
|---|---|---|
| Kids and age-appropriate design | https://developer.apple.com/kids/ | Kids category, child-directed experience, teen/social features |
| App Store categories | https://developer.apple.com/app-store/categories/ | Category and product-type alignment |
| Generative AI HIG | https://developer.apple.com/design/human-interface-guidelines/generative-ai | AI creation, transformation, summarization, recommendations |
| Photos privacy experience | https://developer.apple.com/documentation/photokit/delivering-an-enhanced-privacy-experience-in-your-photos-app | Photo library access and limited-library behavior |
| Accessibility | https://developer.apple.com/documentation/accessibility/ | Accessibility implementation and test routing |

For health, UGC, payments, crypto/finance, gambling, VPN, ads, IP, minimum functionality, and misleading claims, open the current App Review Guidelines and navigate to the matching numbered section. Do not rely only on a remembered number because Apple can revise structure and wording.

## Authority rules

- Use Apple pages as compliance authority.
- Use current laws or regulator sources for legal conclusions; do not infer legal compliance from Apple acceptance.
- Use competitor apps, design galleries, and open-source projects only as design references.
- Paraphrase Apple rules and link to the source. Avoid copying long passages.
- If two Apple sources appear inconsistent, report the conflict and prefer the newer, more specific source while asking Apple Developer Support when the decision is material.

