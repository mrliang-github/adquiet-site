# Product Classification

Build the audit profile from actual behavior, data flow, user-facing claims, and distribution. Product naming and App Store category are signals, not conclusions.

## Fingerprint template

```yaml
platform:
distribution:
primary_job:
core_loop:
audience:
age_range:
content_origin:
accounts:
monetization:
permissions:
on_device_data:
transmitted_data:
third_party_sdks:
ai_features:
user_generated_content:
regulated_claims:
hardware_and_entitlements:
destructive_actions:
backend_dependencies:
store_category:
```

For each field, attach one or more evidence paths or runtime observations.

## Classification order

1. Read the current product brief, README, or PRD.
2. Inspect targets, frameworks, SDKs, entitlements, privacy manifests, and usage descriptions.
3. Trace the first-launch and core-value code paths.
4. Inspect current runtime behavior.
5. Compare current App Store metadata and privacy answers when authorized.
6. Resolve contradictions in favor of current runtime/package evidence.

## Routing rules

| Evidence | Activate |
|---|---|
| HealthKit, medical measurements, health recommendations, body calculations, symptom or diagnostic claims | Health, Fitness, and Medical |
| StoreKit, RevenueCat, paywall, quota, entitlement, external digital purchase | In-App Purchase and Subscriptions |
| Account creation, guest identity, OAuth, Sign in with Apple | Accounts and Sign in with Apple |
| PhotoKit, camera, microphone, AVFoundation, document picker, destructive media actions | Photos, Video, Camera, Microphone, and Files |
| Model API, on-device model, generated image/text/audio, AI classification presented to users | Generative AI and Model-Produced Content |
| Users publish, share publicly, comment, message, follow, or discover other users’ content | User-Generated or Creator Content |
| Kids category, under-13 audience, child-directed copy, social features for minors | Kids, Teens, and Age Rating |
| Trading, wallet, exchange, investment, lending, financial advice, crypto transactions | Finance, Cryptocurrency, and Money Management |
| Games, randomized rewards, contests, sweepstakes, real-money outcomes | Games, Contests, Gambling, and Randomized Rewards |
| Imported books/media, reader content, third-party sites, licensed photos/music/text | Reader Apps, Imported Content, and Intellectual Property |
| CoreLocation, MapKit, local network, VPN, DNS, speed test, security/diagnostic claims | Location, Maps, Local Network, VPN, and Diagnostics |
| Bluetooth, external sensor, companion device, hardware-gated functionality | Hardware, Bluetooth, and Companion Devices |
| Ads, attribution, analytics, tracking permission, device identifiers | Ads, Tracking, Analytics, and Third-Party SDKs |

## False-positive checks

Before activating a regulated module, verify the regulated behavior:

- Physical coin identification is not cryptocurrency trading.
- Device thermal diagnostics are not human health diagnostics.
- Entertainment simulation is not a medical or forensic measurement if every meaningful surface makes the simulation clear.
- A local network diagnostic app is not a VPN unless it configures or operates VPN functionality.
- Bundled AI-produced assets are different from live user-facing generative AI, but still need content rights and truthful metadata checks.
- A private local gallery is not UGC unless users publish or interact with other users’ content.

## Distribution router

Return `NOT_APPLICABLE` when a Developer ID direct-distribution product is presented as an App Store audit target. State the correct next audit:

- Developer ID signing
- Hardened Runtime
- notarization and stapling
- Gatekeeper installation and launch
- privileged/helper behavior
- privacy and support obligations

