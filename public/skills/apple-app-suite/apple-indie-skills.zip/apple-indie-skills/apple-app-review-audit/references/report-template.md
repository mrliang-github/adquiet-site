# Audit Report Template

Use this structure for every completed audit.

```markdown
# [App Name] Apple App Review Preflight

Audit date:
Repository / branch:
Target version / build:
Distribution:
Submission context:

## Verdict

**[PASS | PASS_WITH_RISKS | BLOCKED | NOT_APPLICABLE]**

One paragraph explaining the decision and the highest-impact evidence.

> This is an internal preflight based on Apple public documentation. It does not guarantee App Review approval.

## Product fingerprint

| Field | Current truth | Evidence |
|---|---|---|
| Primary job | | |
| Audience / age | | |
| Content origin | | |
| Accounts | | |
| Monetization | | |
| Data and permissions | | |
| AI / UGC | | |
| Regulated claims | | |
| Hardware / entitlements | | |

## Official source snapshot

| Apple source | Retrieved | Visible update date | Applied areas |
|---|---|---|---|

## Activated modules

- Included:
- Explicitly excluded:

## Blocking and high-risk findings

| ID | Severity | Evidence level | Apple rule | Product evidence | Impact | Smallest fix | Re-verify |
|---|---|---|---|---|---|---|---|

If none, state “No blocker or high-risk finding observed within the verified scope.”

## Research and keyword coverage

Research/coverage readiness: [READY | NEEDS_WORK | NOT_IN_SCOPE, with reason]

| Check | Evidence / applicable version and market | Result / remaining gap |
|---|---|---|
| Prior research and later positioning decisions recovered | | |
| Target storefronts and locales distinguished | | |
| Priority query → exact metadata field → product evidence | | |
| Duplicate, mismatched and unsupported capability terms reviewed | | |
| Unknown search volume/ranking/conversion recorded honestly | | |

Use the shared [research module](../../app-store-release/references/research-and-coverage.md). This is an internal release-readiness check, not an Apple rejection finding. An Apple review PASS does not by itself complete it; quantified demand may remain unknown when the grounded first-iteration rationale is explicit.

## Truth consistency

| Feature or claim | Code/package | Runtime | Metadata/screenshots | Privacy | Purchases/review notes | Result |
|---|---|---|---|---|---|---|

## Reviewer journey

| Step | Result | Evidence | Risk |
|---|---|---|---|
| Clean launch | | | |
| Understand value | | | |
| Permission flow | | | |
| Core task | | | |
| Paid boundary | | | |
| Recovery/error path | | | |

## Design and accessibility

List only actionable findings, tied to an observed screen/state and Apple HIG source.

## Packaging and submission state

| Gate | Current truth | Evidence level | Result |
|---|---|---|---|
| Xcode / SDK | | | |
| Release/archive/signing | | | |
| Privacy manifest/report | | | |
| Version/build | | | |
| IAP/subscriptions | | | |
| Submission | | | |

## Rejection closure

Include only for rejected/resubmitted apps.

| Apple issue | Build reviewed | Remediation claimed | Current evidence | Closed? |
|---|---|---|---|---|

### Draft review note

Keep factual, brief, and reproducible. State where the reviewer can find the fix.

## Residual risk and unknowns

- Unknown:
- Stale evidence:
- Not tested:

## Next actions

1. Exact blocker-clearing action.
2. Exact verification command or manual path.
3. Submission step only after blockers are closed.

## Scope

Files, builds, devices, locales, storefronts, accounts, and App Store Connect objects actually inspected.

STATUS: [DONE | DONE_WITH_CONCERNS | NEEDS_CONTEXT | BLOCKED]
```

## Report rules

- Lead with the verdict.
- Do not hide unknowns in prose.
- Link every blocker/high finding to an Apple primary source.
- Keep internal research/coverage gaps in their own section; do not invent an Apple rule citation for a user-required process check or declare the overall submission ready while it is incomplete.
- Separate rule violations from HIG recommendations.
- Separate current live truth from memory, old screenshots, or previous reports.
- Do not say “approved,” “submitted,” or “live” unless the exact current App Store Connect state proves it.

