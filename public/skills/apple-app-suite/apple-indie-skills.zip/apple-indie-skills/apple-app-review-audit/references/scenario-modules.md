# Scenario Modules

Use the current Apple source wording and identifiers at audit time. This file describes questions to ask, not frozen policy text.

## Always-on modules

### Core App Review

- Does the current build launch, remain stable, and provide complete functionality?
- Are demo credentials, backend services, hardware, and special setup available to the reviewer?
- Are placeholders, broken URLs, sample-only flows, mock data, and inaccessible features absent?
- Does the app provide meaningful native utility and avoid copycat/template/spam risk?
- Are review notes specific about new or non-obvious behavior?

### Metadata and Claim Consistency

- Do name, subtitle, description, screenshots, previews, category, price, and review notes match the submitted build?
- Are paid features visibly identified?
- Are diagnostic, performance, savings, accuracy, privacy, offline, and AI claims demonstrated rather than assumed?
- Are screenshots real representations of the current localized interface?

### Design and Accessibility

- Can a new reviewer understand the value and complete the core task?
- Are permission requests contextual and recoverable after denial or limited access?
- Are destructive actions explicit, confirmed, and consistent with system behavior?
- Are loading, empty, offline, failure, cancellation, and retry states usable?
- When a feature is unavailable, quota-limited, permission-blocked, or paywalled, does the action explain why and offer a next step instead of silently doing nothing?
- Do Dynamic Type, VoiceOver labels, contrast, touch targets, reduced motion, orientation, and supported device sizes work?
- Is the paywall transparent and is the free/paid boundary understandable before commitment?

### Privacy and Data Truth

- What data leaves the device, why, where, for how long, and through which SDK?
- Do privacy policy, App Store privacy answers, privacy manifest, permission prompts, and runtime behavior agree?
- Are required-reason APIs and third-party SDK manifests valid?
- Is data minimization real, especially for photos, health, children, identifiers, and user content?

### Packaging and Submission State

- Does the app use the currently required Xcode/SDK?
- Are version, build, bundle ID, signing, entitlements, encryption declarations, and archive contents correct?
- Are app version, IAP/subscription, and submission objects in compatible current states?
- Does `Ready for Review` merely mean added to a draft, or has Apple actually received the submission?

## Conditional modules

### Accounts and Sign in with Apple

- Is account creation necessary for the core experience?
- If the app creates accounts, can users initiate full account deletion inside the app?
- Are guest/automatic accounts covered?
- Does Sign in with Apple token revocation happen when required?
- Are sign-in choices and reviewer credentials functional?

### In-App Purchase and Subscriptions

- Are digital unlocks using an allowed purchase path?
- Are products localized, reviewable, visible, and attached/submitted correctly?
- Is restore purchase available and tested?
- Is ongoing subscription value clear?
- Are duration, price, renewal, trial, cancellation/management, upgrade/downgrade, and entitlement states understandable?
- Does the app handle interrupted, pending, refunded, expired, offline, and cross-device states?
- When free quota is exhausted or product/entitlement state is unavailable, does every gated action show actionable feedback or the correct paywall instead of returning silently?

### Health, Fitness, and Medical

- Is every visible calculation or recommendation supported by a discoverable method/source?
- Are medical, diagnostic, treatment, sensor-accuracy, and emergency claims appropriately bounded?
- Are HealthKit and other health data used only for permitted user benefit and disclosed specifically?
- Is inaccurate data prevented from being written?
- Are disclaimers being used as a substitute for evidence? If so, flag it.

### Photos, Video, Camera, Microphone, and Files

- Does the app request only the access level needed?
- Does limited Photos access work?
- Is add-only access sufficient for saving?
- Can users understand whether processing is on-device or uploaded?
- Are delete, overwrite, compression, conversion, metadata removal, and storage-savings claims accurate?
- Does cancellation preserve originals and avoid orphaned output?

### Generative AI and Model-Produced Content

- Is AI use clearly identified at the decision point?
- Does the feature provide specific user value and a safe failure/fallback path?
- Can users retry, dismiss, revert, or correct generated output?
- Are input media/text, model provider, retention, and training use disclosed accurately?
- Are unsafe, discriminatory, sexual, violent, impersonating, or IP-infringing outputs addressed?
- If AI output is public or shared, also activate UGC/content moderation.

### User-Generated or Creator Content

- Can users filter, report, block, and reach support?
- Is moderation timely and demonstrable?
- Is mature content controlled consistently with age rating?
- Are creator purchases and access boundaries clear?
- Can the reviewer exercise moderation flows?

### Kids, Teens, and Age Rating

- Does the selected age rating match content, social features, ads, purchases, and user interaction?
- Are parental gates present where required?
- Are child data and third-party transmission restricted?
- Are current age-rating questionnaire changes completed?
- Do social features use the current age-range controls when required?

### Finance, Cryptocurrency, and Money Management

- Is the app actually trading, transacting, advising, lending, or managing money?
- Are developer organization status, licenses, regions, and institutional ownership requirements satisfied?
- Are pricing and financial outcome claims non-misleading?
- If the product only identifies collectible physical coins, exclude crypto rules and document why.

### Games, Contests, Gambling, and Randomized Rewards

- Are contests sponsored correctly with official rules and Apple non-sponsorship disclosure?
- Are randomized paid items and odds handled correctly?
- Are real-money gaming, gambling aids, and geographic licensing involved?
- Does the entertainment positioning avoid false forensic, psychological, or medical claims?

### Reader Apps, Imported Content, and Intellectual Property

- Does the user have rights to imported books, photos, video, music, maps, or other content?
- Are third-party service terms compatible with access and monetization?
- Are bundled content, AI-created assets, licenses, attribution, and source records traceable?
- Is the product a reader app, a creation tool, or a digital-content store? Apply the matching payment rules.

### Location, Maps, Local Network, VPN, and Diagnostics

- Is permission timing tied to a clear user action?
- Are regional map/provider attributions preserved?
- Does the app claim capabilities iOS cannot provide?
- Are security, malware, Wi-Fi, speed, device identity, VPN, and repair recommendations accurately bounded?
- Are local-network targets normalized and protected against unsafe input?
- If VPN behavior exists, verify the current special VPN requirements.

### Hardware, Bluetooth, and Companion Devices

- Can App Review access or understand the app without the physical device?
- Are supported models, protocols, accuracy, calibration, and fallback behavior explicit?
- Do hardware-unlocked features comply with current purchase rules?
- Are Bluetooth and nearby-device permissions contextual?
- Are simulated/demo readings clearly distinguished from real measurements?

### Ads, Tracking, Analytics, and Third-Party SDKs

- Do ATT behavior, IDFA answers, privacy labels, SDK manifests, and privacy policy agree?
- Are ads appropriate for the age rating?
- Is sensitive data excluded from targeting?
- Can users report inappropriate ads where required?
- Are analytics claims such as “no tracking” verified against every embedded SDK?
