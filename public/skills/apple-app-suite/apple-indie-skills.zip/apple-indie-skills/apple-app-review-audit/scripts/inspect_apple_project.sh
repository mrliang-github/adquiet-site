#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: inspect_apple_project.sh <repo-root>" >&2
  exit 64
fi

audit_root="$1"
if [[ ! -d "$audit_root" ]]; then
  echo "Repository directory not found: $audit_root" >&2
  exit 66
fi

audit_root="$(cd "$audit_root" && pwd -P)"

echo "# Apple project evidence scan"
echo
echo "- Repository: $audit_root"
echo "- Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

if git -C "$audit_root" rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "- Git branch: $(git -C "$audit_root" branch --show-current 2>/dev/null || true)"
  echo "- Git status:"
  git -C "$audit_root" status --short --branch | sed 's/^/  /'
else
  echo "- Git: not a repository"
fi

echo
echo "## Project markers"
find "$audit_root" -maxdepth 3 \
  \( -name '*.xcodeproj' -o -name '*.xcworkspace' -o -name 'Package.swift' -o -name 'pubspec.yaml' -o -name 'package.json' \) \
  -not -path '*/node_modules/*' -not -path '*/Pods/*' -not -path '*/build/*' \
  -print | sed 's/^/- /' | head -n 80

echo
echo "## Release and privacy files"
find "$audit_root" -maxdepth 6 \
  \( -name 'Info.plist' -o -name '*.entitlements' -o -name 'PrivacyInfo.xcprivacy' -o -iname '*privacy*.md' -o -iname '*privacy*.html' -o -iname '*app*review*.md' -o -iname '*submission*.md' \) \
  -not -path '*/node_modules/*' -not -path '*/Pods/*' -not -path '*/build/*' -not -path '*/DerivedData/*' \
  -print | sed 's/^/- /' | head -n 160

echo
echo "## Privacy manifest validation"
manifest_count=0
while IFS= read -r manifest_path; do
  manifest_count=$((manifest_count + 1))
  if command -v plutil >/dev/null 2>&1; then
    if plutil -lint "$manifest_path" >/dev/null 2>&1; then
      echo "- VALID: $manifest_path"
    else
      echo "- INVALID: $manifest_path"
    fi
  else
    echo "- UNCHECKED (plutil unavailable): $manifest_path"
  fi
done < <(
  find "$audit_root" -name 'PrivacyInfo.xcprivacy' \
    -not -path '*/node_modules/*' -not -path '*/Pods/*' -not -path '*/build/*' -not -path '*/DerivedData/*' \
    -print
)
if [[ "$manifest_count" -eq 0 ]]; then
  echo "- No PrivacyInfo.xcprivacy found"
fi

echo
echo "## Permission and entitlement declarations"
if command -v rg >/dev/null 2>&1; then
  rg -n --no-heading \
    --glob '*.plist' --glob '*.entitlements' --glob '*.pbxproj' \
    --glob '!**/node_modules/**' --glob '!**/Pods/**' --glob '!**/build/**' --glob '!**/DerivedData/**' \
    'NS(Camera|PhotoLibrary|Microphone|Location|LocalNetwork|Bluetooth|Motion|Health|FaceID|Calendars|Contacts|UserTracking)|com\.apple\.developer\.|aps-environment' \
    "$audit_root" | head -n 240 || true
else
  echo "- rg unavailable"
fi

echo
echo "## Capability signals"
if command -v rg >/dev/null 2>&1; then
  echo "Files containing capability keywords (inspect each match in context):"
  rg -l -i \
    --glob '*.{swift,m,mm,h,dart,ts,tsx,js,jsx,plist,entitlements,pbxproj,yaml,yml,json}' \
    --glob '!**/node_modules/**' --glob '!**/Pods/**' --glob '!**/build/**' --glob '!**/DerivedData/**' --glob '!**/.dart_tool/**' \
    'HealthKit|HKHealth|StoreKit|RevenueCat|Purchases|Product\.products|PhotoKit|PHPhoto|AVFoundation|SFSpeech|SpeechRecognizer|CoreLocation|CLLocation|MapKit|NetworkExtension|NEVPN|NWBrowser|local network|CoreBluetooth|CBCentral|Sign in with Apple|ASAuthorization|AppTrackingTransparency|ATTrackingManager|AdMob|GoogleMobileAds|FirebaseAnalytics|camera|microphone|account deletion|delete account|restore purchases|generative|OpenAI|Gemini|Claude|machine learning|CoreML' \
    "$audit_root" | sed 's/^/- /' | head -n 320 || true
else
  echo "- rg unavailable"
fi

echo
echo "## Distribution signals"
if command -v rg >/dev/null 2>&1; then
  rg -l -i \
    --glob '*.{md,txt,plist,entitlements,pbxproj}' \
    --glob '!**/node_modules/**' --glob '!**/Pods/**' --glob '!**/build/**' --glob '!**/DerivedData/**' \
    'Developer ID|Mac App Store|App Store|notari[sz]|Hardened Runtime|TestFlight' \
    "$audit_root" | sed 's/^/- /' | head -n 120 || true
else
  echo "- rg unavailable"
fi

echo
echo "## Evidence limitations"
echo "- This scan does not prove runtime behavior, App Store metadata, privacy answers, purchase state, or submission state."
echo "- Review every match in context. Keywords can create false positives."
