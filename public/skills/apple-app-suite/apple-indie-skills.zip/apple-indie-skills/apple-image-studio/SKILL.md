---
name: apple-image-studio
description: "按 Apple Image 的宣传意图、营销文案和风格要求，用 image2 制作 App Store 与社交宣传图；内部制作说明不上图。"
allowed-tools: Read, Grep, Glob, Bash, image_gen, view_image
---

# Apple Image Studio

本 Skill 是 `$apple-image` 的视觉生产端，也可以在用户已经提供完整 `Apple Screenshot Job` 时直接调用。先理解产品给谁带来什么结果、本图想让人注意什么，再按营销文案和风格要求让 Image2 完成完整宣传图。不负责重新定位产品、ASO 研究、App Store 上传或脚本式整页修复。

`Bash` 只用于读取文件信息、创建交付目录和复制/重命名完整 Image2 输出；不得用于任何像素变换、背景提取、图层合成或整页渲染。

## 进入条件

production 前必须具备：

- 目标 locale、主 locale 和唯一目标尺寸；
- 已通过事实检查的 Campaign Brief、渠道和宣传意图；
- 同一份 Style Brief；有风格参考图时附上素材及其使用角色，无参考图不阻塞生产；
- 每张图唯一的营销卖点、第一眼应理解的结果，以及各 locale 的 `Public Copy`；
- 每个目标 locale 的真实完整截图；
- 可选的真实重点裁片及含义；
- App icon；
- 已用 `view_image` 检查过的机框绝对路径和可见性要求；
- 必须保持准确的 UI、数字、价格、文字和禁用变化。

缺少真实证据时返回 Director 补充素材或调整主张，不让 Image2 猜测产品事实。

开始 production 前读取 [references/style-selection.md](references/style-selection.md)。

## 文字隔离：说明给模型看，广告给顾客看

读取 Director 的 [交接契约](../apple-image/references/visual-production.md)，使用其中的 `Public Copy` 字段。它是新增上图文字的唯一清单；未填写的副标题、标签、CTA 和限定语不渲染，字段名也不渲染。真实 UI 和真实 Logo 的原有文字保留。

`Product Truth`、`Why it matters`、`First-glance takeaway`、`Style Brief`、`Visual Intent`、素材/示例数据备注、制作过程、兼容性核验记录和 QA 结果均是内部信息。不得把它们直接或改写成画面里的说明、小字或页脚。需要向顾客展示的关键使用条件必须先由 Director 写入 `Public Copy`，不能擅自增加，也不能删除已确定的条件。

如文案还像功能说明、漏掉最重要的结果，或需要增加新文字才能解释画面，先返回 Director 修正文案与证据；不要边画边编卖点。当前用户明确修改文案或风格时，先同步 Job，再按更新后的要求生产。

## 每张图先形成 Visual Intent

根据同一份 `Style Brief`、卖点、用户场景、截图证据形态和相邻页面，为每张图明确内部 `Visual Intent`：

- 用户第一眼应该看到的结果；
- 是否需要现实场景或视觉隐喻，极简产品图可以不使用；
- 背景层次、光线、色彩与材质；
- 手机姿态、近景程度和裁切方式；
- 完整页面与重点证据的空间关系；
- 有助理解的效果，例如重点放大、前后对比、聚光或柔和阴影；没有必要时不添加；
- 为保持系列一致而沿用的品牌元素；
- 为适应不同卖点而与相邻页面形成的必要变化。

用户当前指令优先于既有 `Style Brief`，`Style Brief` 优先于通用风格建议；事实与素材约束始终适用。极简留白、直立手机和克制阴影都是有效选择，不因“丰富度”要求强加玻璃、光轨或场景。主体可以是真实结果、前后变化或具体数字，手机不必总是最大。第一眼能读懂主卖点才是构图依据。

## 主 locale：Image2 一次性完整成片

每张图在同一次 Image2 调用中提供：

- 当前卖点、宣传意图与独立列出的 `Public Copy`；
- Style Brief 与本轮已有的参考图，明确哪些只参考风格、哪些是真实产品证据；
- 完整真实截图；
- 可选真实重点裁片；
- App icon；
- 指定机框图片；
- Visual Intent；
- 必须保持准确和禁止修改的内容；
- 与前后页面的系列关系。

Image2 同时决定背景、场景、文案层级、设备姿态、真实截图呈现、重点放大、阴影、光效和空间节奏。不要拆成“先生成背景、再由脚本放手机”的两阶段生产。

每次生成和编辑都必须包含文字契约，并把最终文字与内部指令分区：

```text
PUBLIC COPY — RENDER ONLY THESE STRINGS
[Insert only the selected locale's exact Public Copy strings, not field names.]

INTERNAL DIRECTION — DO NOT RENDER AS TEXT
All product context, evidence notes, visual intent, style guidance and QA instructions
are for making the image, not words to print on it.
Render no additional captions, explanations, footnotes, badges, watermarks or CTA.
Preserve existing text in the supplied real App UI and authentic logo.
Keep every provided Public Copy string; change only line breaks and visual hierarchy.
```

以上占位行必须替换为本张真实文案，不能原样交给 Image2。兼容性等必要限定语只在 `Public Copy` 已提供时照原文呈现。

机框契约必须写入提示：

```text
Use the attached iPhone hardware frame as the visible device shell.
Replace its black placeholder screen with the attached real App screenshot.
Keep a recognizable metal frame edge and device silhouette visible.
Do not turn the screenshot into a floating rounded card.
Do not invent a different phone, extra bezel, second Dynamic Island, or black screen.
```

主 locale 成片通过视觉与事实检查后成为系列视觉母版。保存完整 Image2 输出，不创建纯背景版本。

## 其他 locale：基于母版的 Image2 编辑

- 一次只处理一个 locale，不能把多种语言的截图同时传给一次调用。
- 输入已通过的主视觉母版，以及当前 locale 的真实截图、重点裁片、`Public Copy` 和地区价格页面；沿用文字隔离契约。
- 保留背景、场景、机框姿态、裁切、光效、重点放大方式和系列节奏。
- 只本地化文案与屏幕证据；允许为文字长度微调文字区域，但不重新设计整张图片。
- 某个 locale 缺少对应素材时只暂停该 locale。

## 视觉与事实验收

用 `view_image` 打开每张全尺寸图片，并与输入素材直接对照。检查：

- 缩略图下是否能从主标题与主视觉看懂最重要的用户结果；与 Job 的 `First-glance takeaway` 核对，而不把这段说明印上去；
- 场景、构图和页面效果是否真正强化卖点；
- 是否符合 `Style Brief` 的配色、留白、主体层级和效果限度；系列是否一致且每张有清楚的认知任务；
- 文案、语言、Logo、UI、数字和价格是否准确；
- 逐项核对新增上图文字是否全部来自当前 `Public Copy`，有无漏字、额外解释、制作备注、占位符或水印；任何内部说明泄漏都不通过；
- 完整页面与重点放大是否能看出来源关系；
- 指定机框是否可辨认，屏幕是否越框，是否存在黑边、断缝、重复状态栏或第二个灵动岛；
- 主要内容是否位于安全区域，缩略图下仍可辨认。

不建设 OCR、自动审美评分或整页像素重构。这里只有直接视觉对照和轻量事实检查。

## 单图重试与停止条件

- 首次通过：标记 `direct_image2`。
- 只有局部错误：把当前完整成片与准确参考重新交给 Image2，只编辑这一张，标记候选为 `image2_retry`。
- 卖点遗漏先回 Director 修正 Job；风格偏离按原 `Style Brief` 修正；文字泄漏删除多余说明并保留 `Public Copy`。不要只加特效或补一行解释。
- 同一张最多进行两次定向编辑；仍无法保证关键价格、数字、UI、文案、机框、风格或文字隔离时，标记 `repair_required` 并停止。
- 不因一张失败改变其他已经通过的图片，也不自动调用本地精确合成。

## 不可变成片规则

通过后的完整 Image2 输出是唯一视觉母版。后续禁止：

- 抽取纯背景板；
- 删除或覆盖整台手机、全部文案或重点卡片；
- 使用 Sharp、Canvas、SVG 或其他脚本重新决定构图；
- 重新设置手机尺寸、角度和位置；
- 把脚本重组结果冒充 Image2 完整成片。

Studio 可以复制或重命名完整输出以便归档，但不得改变画面内容。尺寸和格式转换由 Director 的内容保持式导出脚本完成。

## 输出

每张图返回：

```text
Studio Output
- Slide ID / locale:
- Full Image2 output path:
- Visual intent:
- Source state: direct_image2 | image2_retry | repair_required
- Visual QA result:
- Copy and evidence QA result:
- Public copy isolation QA result:
- Style adherence QA result:
- First-glance message QA result:
- Frame QA result:
- Export eligible: true | false
```

只有 `direct_image2` 或 `image2_retry` 且全部检查通过时，`export_eligible` 才能为 `true`。
