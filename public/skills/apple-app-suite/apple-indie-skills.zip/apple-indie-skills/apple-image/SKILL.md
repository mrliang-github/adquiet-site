---
name: apple-image
description: "为 App Store 截图和小红书等产品宣传图理解产品与传播意图，提炼真实卖点、上图文案和视觉风格，并交给 Studio 生成成片。"
allowed-tools: Read, Grep, Glob, Bash, Write, image_gen, view_image
---

# Apple Screenshot Director

这是用户统一调用的产品宣传图营销入口。任务是理解产品、目标受众和本次宣传意图，让读者第一眼明白“这个产品能为我带来什么”，并愿意进一步了解。负责“产品事实 → 核心卖点 → 上图文案与风格 → 真实证据 → Studio 成片”，不负责用脚本重新设计 Image2 成片。

## 核心边界

- 目标 locale 由用户本轮指定；未指定时只处理当前主 locale，并把可选 locale 作为建议，不擅自扩张。
- 图片数量由本轮意图决定。常规 App Store 套图通常为每个 locale 4–6 张；社交单图、封面和试稿按用户范围制作，不为凑数造卖点。
- 每轮只生产一个目标尺寸。优先使用用户指定尺寸；App Store 使用已确认槽位或产品档案默认值，小红书试稿未指定时可采用 1080×1440，并记录这一选择。
- 每张图只把 `Public Copy` 中的文字作为新增上图文案。产品分析、设计理由、证据备注、生成指令和验收说明均为内部内容。
- 风格通过同一份 `Style Brief` 传给 Studio；用户参考图与本轮意图优先，不默认把所有产品做成白底，也不默认堆叠效果。
- production 中每张以 App UI 为主体的图片默认必须出现指定的真实 iPhone 机框，除非用户明确要求无机框。
- Image2 完整成片是正式视觉来源，不是背景素材。通过后禁止拆背景、删文字、删手机或整页重排。
- App Store Connect 上传、替换截图、撤回审核和重新提交需要对应用户授权；本轮已有明确授权时直接沿用，不按 Skill 或步骤重复确认。制作图片本身不自动授权发行。

## 按需读取

1. 理解产品、营销与 ASO：读取 [references/marketing-strategy.md](references/marketing-strategy.md)。
2. 选择真实截图和重点证据：读取 [references/screenshot-evidence-design.md](references/screenshot-evidence-design.md)。
3. 准备 Studio 生产交接：读取 [references/visual-production.md](references/visual-production.md)。
4. production 前读取 [references/device-frame-assets.md](references/device-frame-assets.md)，解析并检查本轮机框素材。

开始时寻找 `products/<app-slug>/profile.md`。不存在时读取 [references/product-profile.md](references/product-profile.md) 建立；存在时按当前产品状态校正。价格、关键词、竞品和商店状态等时间敏感事实必须带市场与日期。

## 工作流

### 1. 确定本轮范围

记录目标 App、受众、渠道、宣传意图、目标 locale、主 locale、唯一目标尺寸和本轮数量。意图例如吸引首次了解、发布更新或证明某项能力；它决定首图重点。能从上下文确认的直接采用，只有影响结果的关键缺口才询问。

### 2. 建立 Product Truth

- 读取产品档案、当前商店文案、真实 UI 和必要代码。
- 区分稳定功能事实与需要刷新验证的价格、ASO、竞品和商店状态。
- 明确能说什么、不能说什么，以及哪些营销主张需要真实页面或数据证明。
- 找出最值得展示的具体结果及其触发动作，例如“扫描房间 → 生成 3D 户型”；不能用“高效管理”“生成底图”等泛称抹掉产品的核心吸引力。

### 3. 制定动态 Campaign Brief

- 根据用户问题、产品结果和真实差异点决定图片数量与叙事顺序。
- 每张图只表达一个主要卖点；第一张讲核心结果，后续用真实功能证据逐步证明。
- 按 [references/marketing-strategy.md](references/marketing-strategy.md) 写面向顾客的营销文案：具体、易懂、有结果感；用真实价值吸引人，不靠无依据的速度、精度或效果承诺。
- 在内部比较候选后，选择一套 `Public Copy`；品牌名、主标题和必要补充有明确层级。制作说明不得混进标题、副标题、角标或页脚；普通文案选择不新增用户审批步骤。
- 根据用户参考、品牌和本轮意图确定 `Style Brief`，区分视觉气质与表达方式。例如“米白极简”可以搭配“放大 3D 结果”，不等于只能居中放一台手机。
- 每张记录上图文案、所需页面、重点证据和禁用主张。按交接契约把内部信息与 `Public Copy` 分开。
- 找不到真实证据时回到营销阶段调整主张，不允许在视觉阶段补造。

### 4. 准备各 locale 的素材包

- 为每个 Slide 找到对应 locale、页面状态和明暗模式的真实截图。
- 当单条数据、卡片或控制项需要放大时，先从原图提取精确裁片，再与完整截图一起交给 Studio。
- 准备 App icon、已解析机框绝对路径、准确本地化文案，以及价格页等动态内容的当前证据。
- 某个 locale 缺少关键素材时只暂停该 locale，不影响其他已经完备的 locale。

### 5. 交给 `$apple-image-studio`

production 前完整读取 `../apple-image-studio/SKILL.md`，并按 [references/visual-production.md](references/visual-production.md) 交付同一份 `Apple Screenshot Job`。

Studio 负责：

- 依据同一份 `Style Brief`、参考图和每张卖点落实构图与效果，不另起一套风格；
- 只渲染当前 locale 的 `Public Copy`，保留真实 UI 和 Logo 中的原有文字；
- 用 Image2 生成主 locale 完整成片；
- 基于已通过的主视觉生成其他 locale；
- 打开原图验收卖点、风格与上图文字，并仅对失败单图执行 Image2 定向重试。

Director 不得在 Studio 返回后创建新的整页渲染脚本，也不得把 Studio 输出降级为背景板。

用户反馈“没吸引力、核心功能没说出来”时，先重审卖点、标题和结果证据；反馈“风格不对”时，更新 `Style Brief`。不能只换颜色或加特效来应付卖点问题。内部交接与 QA 留在制作记录中，面向用户的交付只说明必要的结果、取舍和未完成项。

### 6. 内容保持式导出

只有 Studio 标记为 `export_eligible: true` 的完整成片才能进入 `scripts/export_appstore_images.sh`。

导出阶段只允许：

- 等比缩放；
- 在纵横比几乎一致时做极轻微中心裁切；
- 转换为目标 PNG；
- 检查尺寸、格式和透明通道。

纵横比明显不匹配时必须退回 Studio 重新生成。尺寸问题不能触发背景提取、机框重建、文案重排或 UI 回填。

### 7. 交接到上架检查

App Store 素材交付记录必须包含产品与调研来源、目标地区／locale、核心用户任务、目标词与字段映射的路径或缺口，以及最终客户文案和素材路径。截图口号不能直接替代商店名称、副标题和关键词设计。

当前任务包含上架、更新商店或提交审核时，完成素材后继续 [app-store-release](../app-store-release/SKILL.md)，核对调研、关键词覆盖、审核与分发条件，再执行已授权动作；不要只因图片导出成功就报告可提交。仅制作图片的任务留下交接记录，不擅自上传或扩展为完整发行。

## 禁止的默认路径

production 默认链路中禁止：

- 从 Image2 成片提取纯背景板；
- 批量删除或覆盖 Image2 中的文案、手机、UI、机框或重点卡片；
- 使用 Sharp、Canvas、SVG 或其他脚本重新设计整张图片；
- 因某一张失败而把整套图片切换为模板合成；
- 把不同 locale 的截图同时交给一次 Image2 调用。

某张连续两次 Image2 定向编辑仍无法通过事实、上图文案、风格或机框检查时，标记为 `repair_required` 并停止该张。不要自动进入本地精确合成；先向用户报告失败区域和可选处理方式。

## 交付状态

每张图只使用以下来源状态：

- `direct_image2`：首次完整生成通过；
- `image2_retry`：单图定向编辑后通过；
- `repair_required`：尚未通过，禁止导出和上传。

最终回复说明本轮 locale、图片数量、唯一尺寸、主视觉方向、每张卖点、机框路径、来源状态、输出目录，以及尚未执行的外部操作。
