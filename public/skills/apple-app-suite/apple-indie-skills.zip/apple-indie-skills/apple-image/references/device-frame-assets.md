# Bundled Device-Frame Assets

production 默认读取本文件。除非用户明确要求无机框，否则每张以 App UI 为主体的成片都使用已解析的真实 iPhone 机框素材。

## Assets

| Orientation | Asset | Pixel size | Intended screen size |
|---|---|---:|---:|
| Portrait | `../assets/device-frames/iphone-17-pro-max-silver-portrait.png` | 1470×3000 | 1320×2868 |
| Landscape | `../assets/device-frames/iphone-17-pro-max-silver-landscape.png` | 3000×1470 | 2868×1320 |

素材由用户提供并存放于本机 skill 内。当前没有记录公开再分发授权；除非用户确认来源和许可，不要把它们打包发布到公开仓库或第三方 skill 市场。

## Production preflight

1. 先读取产品档案中的 `Device frame` 和 `Frame policy`；用户指定素材优先。
2. 没有项目专用素材时，直接使用上表中与方向匹配的内置机框，不要只在当前 App 项目里搜索。
3. 将相对路径按本文件目录解析为绝对路径，并用 `view_image` 验证素材存在、方向正确且没有损坏。
4. 把解析后的绝对路径写入每个 `Slide Spec`，并在每次 image2 调用中作为图片引用实际附加。
5. 如果路径缺失、素材无法读取或当前工具不能传入机框，停止 production；不能退化为无机框截图卡片。

## Important limitation

两张 PNG 的画布外侧带透明通道，但内部屏幕区域是黑色填充，不是已经挖空的透明屏幕。它们可以直接作为 image2 的硬件参考素材，但不能直接作为精确覆盖层放在截图上方，否则黑屏会挡住真实 UI。

根据素材和目标屏幕尺寸推算，初始嵌入位置可能是：

- Portrait: `x=75, y=66, width=1320, height=2868`
- Landscape: `x=66, y=75, width=2868, height=1320`

这些坐标只是尺寸推算，不是已验证的像素级校准结果。进入 `exact_composite` 前必须制作屏幕遮罩，并用真实截图检查四角、边框、灵动岛和按钮位置。

## Reference-asset production

当用户希望“把机框当作素材，让模型自由配合”时：

1. 选择与 App 截图方向一致的一张机框，不要同时传入竖版和横版。
2. 把 App 截图和机框作为两个角色清晰分开的参考图传入 image2。
3. App 截图是屏幕 UI 的唯一事实来源；机框只定义银色材质、外形比例、边框和硬件细节。
4. 允许模型根据当前卖点和背景选择直立、轻微倾斜、局部出框、近景裁切或与装饰元素互动，不要预先锁死同一坐标。
5. 不允许模型保留黑屏、生成第二个灵动岛、添加额外按钮、拉长设备、改成 Android 风格，或重画 App UI。

生成后只有同时通过 UI 保真、机框可见性与一致性、文字准确性和目标尺寸检查，才可以继续作为 production 候选；否则定向重试，不可上传。

## Exact-composite promotion gate

只有满足以下条件后，才把素材从 `reference_asset` 提升为 `exact_composite`：

- 屏幕遮罩已经保存为独立资源；
- portrait 和 landscape 的嵌入矩形、圆角和裁切均已校准；
- 真实 UI 的安全区像素对比通过；
- 不出现黑边、透明缝隙、重复状态栏或重复灵动岛；
- 合成脚本和验证脚本可以在不同 App 截图上重复得到相同结果。
