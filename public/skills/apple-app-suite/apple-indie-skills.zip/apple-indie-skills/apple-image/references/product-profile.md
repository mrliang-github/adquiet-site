# App Product and ASO Profile

每个 App 在 `products/<app-slug>/profile.md` 保存一份独立档案。它是营销截图的长期上下文，不是商店实时状态的永久真相。

## 读取顺序

1. Skill 内 `products/<app-slug>/profile.md`。
2. 项目内最新的产品文档、App Store 文案和真实 UI。
3. 带日期的 ASO 软件/App Store Connect/人工研究快照。
4. 必要时读取代码验证功能、导航和明暗模式。

发生冲突时，当前可验证的产品状态优先。时间敏感数据必须保留来源和日期。

## 档案结构

```markdown
# <App name>

- Slug:
- Bundle ID:
- Project paths:
- Last verified:

## Product truth

- Category / job:
- Core promise:
- Primary users:
- Real user problems:
- Verified features:
- Processing/privacy boundary:
- Monetization facts:
- Unsupported or forbidden claims:

## UI truth

- Supported languages:
- Light mode:
- Dark mode:
- Root navigation:
- Key screens:
- Dynamic or risky UI:

## Brand assets

- App icon / Logo:
- Brand colors:
- Device frame:
- Frame policy: required_visible | explicitly_none
- Existing screenshot roots:

## Market positioning

- Primary market:
- Positioning:
- Message hierarchy:
- Differentiators:
- Competitor claims that require verification:

## ASO snapshots

### <YYYY-MM-DD> — <source/tool>

- Market / locale:
- Raw source path or URL:
- Observed facts:
- Tool recommendations:
- Our inference:
- Refresh trigger:

## Screenshot strategy

- Default phone size:
- Default locales:
- Recommended sequence:
- Visual direction:
- Frame visibility direction:
- Allowed appearance variants:
- Claims to avoid:
```

## ASO 软件接入

不要把某个未知供应商写死在通用 SKILL.md。对每个 App，在档案的 `ASO snapshots` 中登记：

- 软件或数据源名称。
- 调用方式：已安装 connector/CLI、网页导出，或用户提供的 CSV/JSON/PDF/截图。
- 市场、语言、时间范围和抓取日期。
- 原始证据路径，不覆盖旧快照。
- 工具直接给出的建议与我们基于产品做出的推断分开记录。

如果软件需要登录或凭据，只记录“如何调用”和所需权限，不把凭据复制进 skill。没有明确软件名或可用工具时，创建中立入口并等待数据，不猜测供应商或指标。
