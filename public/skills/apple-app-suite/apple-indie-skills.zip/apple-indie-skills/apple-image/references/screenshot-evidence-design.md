# Screenshot Evidence Design Module

在 `Campaign Brief` 通过后读取本模块。目标是把每个营销主张映射为用户一眼能看懂的真实界面证据。

## 截图盘点

为候选截图记录：

- 文件路径、像素尺寸、语言、浅色/暗色模式。
- 页面和当前状态，例如空状态、配置状态、处理中或结果页。
- 能证明的卖点与不能证明的内容。
- 动态风险：文件名、价格、额度、个人数据、日期、结果数字和历史购买文案。

优先补录缺失的关键状态，而不是强迫现有截图承担不适合的卖点。

## 证据匹配

每个主张只选一个主要证据目标：

- 整页结构：用于展示工具广度或简单工作流。
- 单个控制项：用于展示精细参数与选择权。
- 单行数据或结果数字：用于展示压缩结果、节省空间或处理明细。
- 单张功能卡：用于展示具体任务入口。
- 前后状态：仅在两边都是真实、可比数据时使用。

不要仅因为某张图视觉上丰富就选它；证据必须能在几秒内支撑标题。

## 局部放大策略

当完整页面包含多条数据，而卖点依赖其中一条时：

1. 保留完整页面或足够的上下文，让用户知道数据来自哪里。
2. 标记目标区域的源图像素矩形 `x, y, width, height`。
3. 用 `scripts/extract_focus_region.sh` 从原图提取精确像素。
4. 将该区域作为放大卡片、近景切片或聚光目标；周围可增加阴影、描边、连接线或柔和暗化。
5. 放大只改变尺度和视觉层级，不改数字、文字、图标、颜色含义或行内关系。

优先选择面积最小但语义完整的区域：单条数据应包含必要标签和结果，不能只截一个失去含义的数字。

## 可选处理方式

- `full_context`：整页为主，适合简单页面。
- `focus_card`：整页加一块精确放大的 UI 切片。
- `spotlight`：降低非目标区域对比度，突出原位置。
- `close_crop`：直接以关键区域为视觉主体，但保留足够上下文。
- `before_after`：两个真实状态并列；禁止伪造前后数据。
- `sequence`：用两张连续截图表达步骤，只有单图无法讲清时采用。

## Slide Spec

```text
Slide Spec
- Slide ID and marketing claim:
- Source screenshot:
- Locale / appearance / UI state:
- Primary evidence target:
- Focus rect in source pixels:
- Treatment: full_context | focus_card | spotlight | close_crop | before_after | sequence
- Context that must remain visible:
- Exact pixels that must not be redrawn:
- Headline / optional support copy:
- Intended visual hierarchy:
- Frame policy: required_visible | explicitly_none
- Resolved frame asset absolute path:
- Frame visibility: full silhouette | top-and-sides visible | intentional close crop
- Risk checks:
```

## 通过条件

- 每个卖点都有对应源截图；源图不能证明时退回营销模块修改主张。
- 每个放大区域都有明确坐标和语义，不依赖 image2 猜测。
- 同一套图的证据方式有变化，但变化服务于理解，不为炫技。
- 已清除或避开过期价格、额度、Pro、恢复购买和敏感数据。
- production 默认使用 `required_visible`，且每张图都已经解析出真实机框素材的绝对路径。只有用户明确要求无机框时才允许 `explicitly_none`。
- `full_context`、`focus_card` 和 `spotlight` 至少保留一台可辨认的 iPhone 设备外形；局部裁片不能取代主设备机框。
