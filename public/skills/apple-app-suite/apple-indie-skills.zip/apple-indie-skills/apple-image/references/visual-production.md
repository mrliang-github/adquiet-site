# Apple Image Studio Handoff

在 `Campaign Brief`、截图证据和机框素材准备完成后读取本文件。它定义 Director 与 `$apple-image-studio` 之间的生产契约，避免 Studio 输出在后续被脚本重新设计。

## Apple Screenshot Job

```text
Apple Screenshot Job
- App:
- Channel and campaign intent:
- Target locales:
- Primary locale:
- Single target size:
- Product Truth:
- ASO evidence and date:
- Campaign Brief:
- Style Brief:
  - Reference images (absolute path, role, traits to retain or avoid):
  - Visual character, palette and typography:
  - Composition and first visual focus:
  - Device and evidence treatment:
  - Series constants and allowed variation:
  - Effects to use or avoid:
- Slide count and narrative order:
- App icon absolute path:
- Resolved frame absolute path and visibility rule:
- Forbidden or stale claims:

Slides
- Slide ID:
  - One marketing claim:
  - Why it matters:
  - First-glance takeaway:
  - Public Copy per locale:
    - Product name (optional):
    - Headline:
    - Subheadline (optional):
    - Benefit labels (optional):
    - CTA (optional):
    - Essential qualifier (optional):
  - Full screenshot per locale:
  - Optional exact focus crop per locale:
  - Evidence treatment:
  - Context that must remain visible:
  - UI, data, price and copy that must remain accurate:
  - Visual opportunity:
  - Relationship to adjacent slides:
```

图片数量和 locale 数量均来自当前 Job，不得假定固定为 5 张或 3 个 locale。

## 上图文字与风格契约

- `Public Copy` 是新增上图文字的唯一清单，逐字提供当前 locale 的最终文案；可选字段留空就不渲染。字段名不属于文案。
- 真实截图和真实 Logo 中已有的文字按原素材保留，不受新增文案清单限制；不得借此新增假 UI、角标或水印。
- 其余 Job 字段全部是内部制作信息：帮助理解与设计，不能直接或改写后印成标题、副标题、注释、页脚。尤其不自动上图 `Why it matters`、`First-glance takeaway`、证据备注与 `Visual Intent`。
- 图像提示中将最终上图文字放入独立 `PUBLIC COPY — RENDER ONLY THESE STRINGS` 区域；其他内容放入 `INTERNAL DIRECTION — DO NOT RENDER AS TEXT` 区域。两者不能合并成一段含糊的“文案”。
- Studio 可以调整文字视觉层级与换行，不能自行改营销承诺、增加解释或 CTA。需要改词时先由 Director 更新 `Public Copy`；用户已有明确授权的常规选稿无需重复确认。
- `Style Brief` 是两端共用的风格要求，参考图只按指定角色使用。实际产品、UI 和结果证据以本产品素材为准。极简可搭配结果放大，不能因默认“丰富度”要求加上冲突的装饰。
- 旧 Job 只有 `Locale copy` 时，先整理成上述 `Public Copy` 与内部字段再生产；不能把混在一起的说明直接传给 Image2 渲染。

## Studio 输出契约

Studio 为每张图返回：

```text
Studio Output
- Slide ID / locale:
- Full Image2 output path:
- Visual intent:
- Source state: direct_image2 | image2_retry | repair_required
- Visual QA result:
- Copy and evidence QA result:
- Public copy isolation QA result:
- Style adherence QA result:
- First-glance message QA result:
- Frame QA result:
- Export eligible: true | false
```

- `direct_image2` 和 `image2_retry` 输出都是完整成片，必须直接作为导出输入。
- `repair_required` 禁止导出和上传；Director 只能报告或在获得方向后继续处理。
- 不存在默认的 `background`、`reconstructed-final` 或“脚本精确版”中间状态。

## 内容保持式导出契约

导出脚本只能接收 `Full Image2 output path`，不能同时接收截图、机框、文案、重点裁片或背景素材。

允许变化：

- 分辨率；
- 文件格式；
- 色彩/透明通道规格；
- 纵横比近似一致时的极少边缘像素。

禁止变化：

- 文案、UI、数字和价格；
- 手机尺寸、角度和位置；
- 机框、阴影、反射和光效；
- 背景场景、重点卡片和空间关系。

如果导出阶段发现视觉问题，应回到 Studio 对原图执行 Image2 定向重试，而不是在导出阶段修图。
