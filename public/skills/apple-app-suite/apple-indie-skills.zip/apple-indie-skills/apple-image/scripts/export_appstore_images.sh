#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  export_appstore_images.sh [--size WIDTHxHEIGHT] --out OUT_DIR IMAGE...
  export_appstore_images.sh [--size WIDTHxHEIGHT] --out OUT_DIR --from-dir SRC_DIR

Exports approved full Image2 artwork to an exact App Store screenshot size.
Only proportional resize and a tiny center crop are allowed. Inputs whose
aspect ratio would crop more than 1% are rejected instead of being redesigned.
The default target is one iPhone portrait size: 1320x2868.
Original files are never modified.

Examples:
  export_appstore_images.sh --out ./export ./raw/*.png
  export_appstore_images.sh --size 1320x2868 --out ./export --from-dir ./raw
USAGE
}

target_size="1320x2868"
max_crop_fraction="0.01"
out_dir=""
from_dir=""
declare -a inputs=()

while [[ $# -gt 0 ]]; do
  case "$1" in
    --size)
      target_size="${2:-}"
      shift 2
      ;;
    --out)
      out_dir="${2:-}"
      shift 2
      ;;
    --from-dir)
      from_dir="${2:-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    --)
      shift
      while [[ $# -gt 0 ]]; do
        inputs+=("$1")
        shift
      done
      ;;
    -*)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
    *)
      inputs+=("$1")
      shift
      ;;
  esac
done

if [[ ! "$target_size" =~ ^[0-9]+x[0-9]+$ ]]; then
  echo "Invalid --size '$target_size'. Expected WIDTHxHEIGHT, e.g. 1320x2868." >&2
  exit 2
fi

if [[ -z "$out_dir" ]]; then
  echo "--out is required." >&2
  usage >&2
  exit 2
fi

target_w="${target_size%x*}"
target_h="${target_size#*x}"

if [[ -n "$from_dir" ]]; then
  if [[ ! -d "$from_dir" ]]; then
    echo "--from-dir is not a directory: $from_dir" >&2
    exit 2
  fi
  while IFS= read -r -d '' file; do
    inputs+=("$file")
  done < <(find "$from_dir" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' \) -print0 | sort -z)
fi

if [[ ${#inputs[@]} -eq 0 ]]; then
  echo "No input images." >&2
  usage >&2
  exit 2
fi

mkdir -p "$out_dir"

tmp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT

count=0
for input in "${inputs[@]}"; do
  if [[ ! -f "$input" ]]; then
    echo "Input image not found: $input" >&2
    exit 2
  fi

  base="$(basename "$input")"
  stem="${base%.*}"
  dest="$out_dir/$stem.png"
  tmp="$tmp_dir/$stem-resized.png"

  width="$(sips -g pixelWidth "$input" 2>/dev/null | awk '/pixelWidth/ {print $2}')"
  height="$(sips -g pixelHeight "$input" 2>/dev/null | awk '/pixelHeight/ {print $2}')"

  if [[ -z "$width" || -z "$height" ]]; then
    echo "Unreadable image: $input" >&2
    exit 2
  fi

  crop_fraction="$(
    awk -v w="$width" -v h="$height" -v tw="$target_w" -v th="$target_h" '
      BEGIN {
        source_ratio = w / h
        target_ratio = tw / th
        if (source_ratio > target_ratio) {
          lost = 1 - (target_ratio / source_ratio)
        } else {
          lost = 1 - (source_ratio / target_ratio)
        }
        printf "%.6f\n", lost
      }
    '
  )"

  if ! awk -v lost="$crop_fraction" -v limit="$max_crop_fraction" 'BEGIN { exit !(lost <= limit) }'; then
    crop_percent="$(awk -v lost="$crop_fraction" 'BEGIN { printf "%.2f", lost * 100 }')"
    echo "Aspect ratio mismatch for $input would crop ${crop_percent}% of one dimension; maximum is 1.00%. Regenerate at the target ratio instead." >&2
    exit 3
  fi

  read -r resized_w resized_h < <(
    awk -v w="$width" -v h="$height" -v tw="$target_w" -v th="$target_h" '
      BEGIN {
        sw = tw / w
        sh = th / h
        scale = (sw > sh) ? sw : sh
        printf "%d %d\n", int(w * scale + 0.5), int(h * scale + 0.5)
      }'
  )

  sips -s format png -z "$resized_h" "$resized_w" "$input" --out "$tmp" >/dev/null
  sips -s format png -c "$target_h" "$target_w" "$tmp" --out "$dest" >/dev/null

  output_w="$(sips -g pixelWidth "$dest" 2>/dev/null | awk '/pixelWidth/ {print $2}')"
  output_h="$(sips -g pixelHeight "$dest" 2>/dev/null | awk '/pixelHeight/ {print $2}')"
  output_format="$(sips -g format "$dest" 2>/dev/null | awk '/format:/ {print $2}')"
  output_alpha="$(sips -g hasAlpha "$dest" 2>/dev/null | awk '/hasAlpha/ {print $2}')"

  if [[ "$output_w" != "$target_w" || "$output_h" != "$target_h" || "$output_format" != "png" ]]; then
    echo "Invalid export $dest: expected ${target_w}x${target_h} PNG, got ${output_w}x${output_h} ${output_format}." >&2
    exit 3
  fi
  if [[ "$output_alpha" == "yes" ]]; then
    echo "Invalid export $dest: alpha channel remains. Provide opaque Image2 artwork or flatten it without changing the composition." >&2
    exit 3
  fi

  crop_percent="$(awk -v lost="$crop_fraction" 'BEGIN { printf "%.2f", lost * 100 }')"
  echo "Exported without reconstruction (${crop_percent}% edge crop): $input -> $dest"
  count=$((count + 1))
done

echo "Exported $count image(s) to $out_dir"
sips -g pixelWidth -g pixelHeight -g format -g hasAlpha "$out_dir"/*.png
