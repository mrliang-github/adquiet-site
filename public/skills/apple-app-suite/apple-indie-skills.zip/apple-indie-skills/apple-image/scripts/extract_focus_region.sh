#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  extract_focus_region.sh --rect X,Y,WIDTH,HEIGHT --out OUTPUT.png [--scale FACTOR] INPUT

Extracts an exact UI region from a source screenshot and optionally enlarges it.
Coordinates are source-image pixels. The input is never modified.
USAGE
}

rect=""
output=""
scale="1"
input=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --rect)
      rect="${2:-}"
      shift 2
      ;;
    --out)
      output="${2:-}"
      shift 2
      ;;
    --scale)
      scale="${2:-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    -*)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
    *)
      if [[ -n "$input" ]]; then
        echo "Only one input image is supported." >&2
        exit 2
      fi
      input="$1"
      shift
      ;;
  esac
done

if [[ ! "$rect" =~ ^[0-9]+,[0-9]+,[1-9][0-9]*,[1-9][0-9]*$ ]]; then
  echo "Invalid --rect '$rect'. Expected X,Y,WIDTH,HEIGHT in source pixels." >&2
  exit 2
fi

if [[ ! "$scale" =~ ^[0-9]+([.][0-9]+)?$ ]] || ! awk -v value="$scale" 'BEGIN { exit !(value > 0) }'; then
  echo "Invalid --scale '$scale'. Expected a positive number." >&2
  exit 2
fi

if [[ -z "$output" || -z "$input" ]]; then
  echo "--out and one input image are required." >&2
  usage >&2
  exit 2
fi

if [[ ! -f "$input" ]]; then
  echo "Input image not found: $input" >&2
  exit 2
fi

IFS=',' read -r crop_x crop_y crop_w crop_h <<< "$rect"
source_w="$(sips -g pixelWidth "$input" 2>/dev/null | awk '/pixelWidth/ {print $2}')"
source_h="$(sips -g pixelHeight "$input" 2>/dev/null | awk '/pixelHeight/ {print $2}')"

if [[ -z "$source_w" || -z "$source_h" ]]; then
  echo "Unreadable input image: $input" >&2
  exit 2
fi

if (( crop_x + crop_w > source_w || crop_y + crop_h > source_h )); then
  echo "Crop rectangle exceeds source bounds ${source_w}x${source_h}." >&2
  exit 2
fi

output_dir="$(dirname "$output")"
mkdir -p "$output_dir"
tmp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT

cropped="$tmp_dir/cropped.png"
sips -c "$crop_h" "$crop_w" --cropOffset "$crop_y" "$crop_x" "$input" --out "$cropped" >/dev/null

read -r output_w output_h < <(
  awk -v w="$crop_w" -v h="$crop_h" -v factor="$scale" '
    BEGIN { printf "%d %d\n", int(w * factor + 0.5), int(h * factor + 0.5) }
  '
)

sips -z "$output_h" "$output_w" "$cropped" --out "$output" >/dev/null
echo "Extracted ${crop_w}x${crop_h} at (${crop_x},${crop_y}); output ${output_w}x${output_h}: $output"
