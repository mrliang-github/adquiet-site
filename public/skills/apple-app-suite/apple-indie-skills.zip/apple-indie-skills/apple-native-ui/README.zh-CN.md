# Apple Native UI Skill v0.1.0

用于把苹果 HIG、项目风格和明确页面任务结合起来，生成/实现/审查 iOS 与 watchOS 界面。
这是当前会话整理的可编辑、独立工作流包，不是 Apple 官方产品，不是审核认证。

## 建议怎样用

先在一个项目使用本包，再选择一个 SwiftUI 编程 Skill 补充代码能力。
不要同时堆叠多个重复的 HIG/SwiftUI 风格规则。保持项目配置为产品范围的唯一来源。

通用风格是 `profiles/native-utility.md`。腕笺额外读取 `profiles/wristquill.md`。
其他产品用 `templates/project-style.md` 建立自己的 `design/apple-ui-profile.md`。
录音隐私、无摘要和手表页面等腕笺规则不会自动污染其他项目。

## 包内文件

- `SKILL.md`：何时触发、读哪些资料、如何设计/实现/审查、交付门槛。
- `references/`：基础、iOS、watchOS、SwiftUI、检查与官方来源。
- `profiles/`：可替换风格和腕笺产品约束。
- `templates/`：项目配置、页面任务卡、出图说明、审查报告。
- `examples/`：调用示例与同一套示例记录数据。
- `scripts/`：结构化 screen spec 校验和对应单元测试。无第三方 Python 依赖。

## 安装：复制一个文件夹，不必部署服务

本轮核验文档日期 2026-10-22；不同旧客户端的支持情况可能不同。
完整 Skill 文件夹必须包含 SKILL.md 和相对路径参考资料，不能只复制入口文件。

| 工具 | 项目内路径 | 手动调用 |
|---|---|---|
| Codex | `.agents/skills/apple-native-ui/SKILL.md` | `$apple-native-ui` 或自然语言指定 |
| Cursor | `.agents/skills/apple-native-ui/SKILL.md` 或 `.cursor/skills/apple-native-ui/SKILL.md` | `/` 选择 Skill 或自然语言指定 |
| Claude Code | `.claude/skills/apple-native-ui/SKILL.md` | `/apple-native-ui` |

Codex 和 Cursor 当前文档均支持 `.agents/skills`，同一项目只保留一份该 Skill 即可。
跨工具共享时可按各工具文档配置链接；不要复制多份同名 Skill 后忘记同步更新。
无需安装 MCP。此 ZIP 不是已安装的 ChatGPT 模板卡，也不会自动同步到你的电脑。
普通聊天中可上传本包或相关 Markdown 并显式要求按它工作，但不等于安装持久 Skill。

### macOS 手动复制示例

先解压；在“包含 apple-native-ui 文件夹”的目录执行下列任一组命令。
将 PROJECT 改成真实项目绝对路径。目标存在时脚本停止，不覆盖已有自定义。

```sh
# Codex / Cursor（项目级，择一位置）
PROJECT="/你的项目绝对路径"
DEST="$PROJECT/.agents/skills/apple-native-ui"
if [ ! -d "$PROJECT" ] || [ ! -f apple-native-ui/SKILL.md ]; then
  echo "请检查 PROJECT 和解压位置。"
elif [ -e "$DEST" ]; then
  echo "目标已存在，请人工比较后更新，不要直接覆盖。"
else
  mkdir -p "$PROJECT/.agents/skills" && cp -R apple-native-ui "$DEST"
fi
```

Claude Code 将上面的 `.agents/skills` 两处改为 `.claude/skills`。
重新打开会话或刷新 Skill 列表，确认能找到 `apple-native-ui`，再显式调用测试。
有现有 AGENTS.md/CLAUDE.md 的项目可人工加一句“Apple 原生 UI 任务使用 apple-native-ui 并读取项目配置”，
不要为了安装本包覆盖原项目说明。

## 一次调用示例

```text
使用 apple-native-ui Skill。
产品：腕笺，读取 profiles/wristquill.md。
这次画 Apple Watch 录音中和已保存两个状态，不新增功能。
按任务卡确定状态、组件和入口，显示为状态对照，不画成所有页面必经流程。
目标系统与 UI Kit 未确认时明确标记，不宣称真机验证通过。
```

其他示例在 `examples/invocation-prompts.md`。

## 检查脚本

在本 Skill 目录运行：

```sh
python3 scripts/validate_screen_spec.py examples/wristquill-screen-spec.json
python3 -m unittest discover -s scripts -p 'test_*.py' -v
```

脚本只做 JSON 数据/状态一致性检查：必需字段、记录引用、时间范围、同记录元信息、
单一转写状态、无依据的确定进度和部分腕笺范围约束。它不读取生成图片，
不扫描 SwiftUI，不验证触控尺寸/VoiceOver/真实传输，不输出“苹果合规”认证。

## 已做与未做

已做：读取前文规范；核验列明的 Apple 官方设计正文；整理规则、模板和产品配置；
对随包结构化检查器运行测试；检查打包内容与文件引用。
未做：在你的 Codex/Cursor/Claude Code 安装；实际调用绘图模型进行前后 A/B 比较；
Xcode 构建、模拟器、Apple Watch 真机或完整无障碍验收。

## 更新与来源

规则追溯见 `references/official-sources.md`。主入口保持短，细节按需读取。
旧版腕笺规范里的“28 pt 最小”不直接继承为按钮通用目标；本次以 Buttons 的一般 44×44 pt 建议为依据。
旧效果图不作为批准的原生样式模板；以前出现的云朵传输图标、假按钮和拥挤列表都列入检查。

不包含 Apple 字体、UI Kit、品牌图标或第三方 Skill 全文。需要官方素材时自行从官方入口
按对应条款取得。将本包公开发布前，应检查并去掉不想公开的产品配置与示例。
