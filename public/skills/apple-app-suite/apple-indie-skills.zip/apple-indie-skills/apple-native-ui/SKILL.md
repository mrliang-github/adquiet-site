---
name: apple-native-ui
description: >-
  Design, review, or implement native iOS and watchOS interfaces using Apple HIG,
  platform-native components, project-specific style profiles, explicit screen states,
  and evidence-based checks. Use for Apple 原生 UI、iPhone 页面、Apple Watch 页面、
  SwiftUI 界面、HIG 审查、原生风格设计稿与出图说明。Do not use as a generic web
  landing-page or Apple-marketing-style generator.
metadata:
  version: "0.1.0"
  reviewed: "2026-10-22"
  scope: "iOS and watchOS"
---

# Apple Native UI

把页面任务、苹果平台惯例和产品风格转换为可检查的设计。不是 Apple 官方 Skill，
不保证审核通过，不把一张生成图片当成已验证的原生 UI。

## 0. 触发边界

- 用于 iOS/watchOS 页面设计、静态效果图、原生 SwiftUI 实现和针对性审查。
- 已有画面仅当用户明确作为参考时使用；不得把以前 AI 生成图当作官方组件。
- 不把 Web/HTML 原型称作原生实现；其他 Apple 平台需另外核实平台规则。
- Skill 只组织已有工具，不能凭空增加绘图、Figma、Xcode、模拟器或设备能力。
- 遵守宿主的安全、权限、工具和输出要求；不安装依赖、修改全局配置或上传项目。

## 1. 先读最小必要上下文

先读 [基础规则](references/foundations.md)。再按任务读取：

| 任务 | 读取文件 |
|---|---|
| iPhone 页面 | [iOS 规则](references/ios.md) |
| Apple Watch 页面 | [watchOS 规则](references/watchos.md) |
| SwiftUI 实现 | [原生实现](references/swiftui.md) |
| 审查／任何交付前 | [检查与证据](references/review.md) |
| 新材质、具体尺寸、组件可用性 | [官方来源与核验策略](references/official-sources.md) |
| 默认工具型风格 | [native-utility](profiles/native-utility.md) |
| 产品是腕笺／WristQuill | [腕笺配置](profiles/wristquill.md) |

不要每次加载全部参考文档。产品配置不能自动套用到另一个 App。
优先读取用户提供的配置或仓库中的 `design/apple-ui-profile.md`；没有才使用默认风格。

## 2. 锁定本次任务，不重问已知信息

确认产品、平台、页面任务、状态、输出模式，以及目标系统／最低系统／UI Kit 版本。
从当前需求、项目文件和已有明确决策中取值。缺失的非阻塞项标为假设；
核心任务完全不明时才问一个关键问题。默认使用用户当前语言，不擅自改成英文 UI。

用 [页面任务卡](templates/screen-brief.md) 组织：
`screen ID → task → entry → one coherent state → primary action → next state`。

- 独立页面、同页状态、系统弹层必须分清。
- 页面排序不等于用户路径；箭头仅表示真实转移。
- 不为美观新增标签、会员、AI 功能、账号或不在范围内的页面。
- 每条规则区分 `HIG 建议`、`API/系统约束`、`项目约定`。
- 平台硬限制不能被品牌要求覆盖；项目可选择不同于 HIG 建议的方案，但说明取舍。

## 3. 先决定原生组件，再决定装饰

为关键区域记录“任务 → 标准组件 → 自定义理由”。
默认优先系统导航、List/Form、Button、TextEditor、ProgressView、系统分享。
使用系统文字样式和语义颜色。自定义必须有任务上的收益，不能只是“看起来更炫”。

品牌可改变内容气质、强调色和自有插画；不要因此破坏系统操作、可读性、状态语义。
不固定全 App 的统一圆角，不用大面积玻璃／渐变／光晕替代层级。

## 4. 按输出模式执行

### A. 设计／出图

使用 [出图说明模板](templates/image-brief.md)。生成前先完成任务卡和状态检查。
默认每张一页；对照板最多 3 个手机画面或 4 个手表画面，这是项目清晰度约定。
将页号、状态与说明放设备外。App 里不放设计规则或宣传卖点。

不要擅画可用性未经核实的系统界面。未经授权/安装的系统资源不随包分发。
只能生成概念图时，标明概念性质，不写“官方 UI Kit 已应用”“尺寸已验证”。
有图像工具时按宿主调用；没有时输出设计说明并披露能力，不伪造已出图。
若宿主要求图片生成后不再输出文字，则把必要的“概念稿”标识放在画面外，
不要为了交付审查报告违反宿主的输出约定；也不要虚构生成后审查已经发生。

### B. SwiftUI 实现

先检查工程目标、当前组件与部署版本；不自行提高最低 OS。
遵循 [原生实现](references/swiftui.md)，只实现本次范围。
生成状态预览，工具具备时运行构建、截图和针对性测试。
没有 Xcode/macOS 或设备时明确“未构建／未实机验证”，不把静态阅读当成通过。
可按需配合一个 SwiftUI 编程 Skill，不要求安装多个重叠规则库。

### C. 审查

必须读实际给定的页面／截图／代码，不凭描述宣称已测试。
按 [审查报告模板](templates/review-report.md) 指出问题位置、影响、修正和证据。
对截图只能报告可见问题与运行风险；不能推断 VoiceOver 标签、真实 pt 和后台行为。

## 5. 交付门槛

按 [检查与证据](references/review.md) 完成以下三层：
1. 任务层：主操作、导航、状态、示例数据是否自洽。
2. 平台层：组件、文字、颜色、手表密度、系统弹层是否适合平台。
3. 验证层：区分目测、代码、构建、模拟器、真机证据；没有测过的写“待验证”。

存在明显状态矛盾、误导图标、伪造进度或主操作缺失时，先修改再交付。
工具无法修正时说明具体残留问题，不把它标成已完成的生产稿。

若已形成结构化 screen spec，可运行：
`python3 <skill-root>/scripts/validate_screen_spec.py <screen-spec.json>`。
此脚本仅检查约定的数据字段、状态与时间，不检查图片或 SwiftUI，也不证明 HIG 合规。
脚本是按需工具，不在普通出图任务中强制制造额外文件。

## 6. 结果与维护

默认交付用户请求的图／代码／审查，附最少必要假设与未验证项。
平台规则来源引用官方文档，产品判断明确属于项目约定。
精确值、版本或 API 有疑问时再查相关官方页，不每次抓取全部 HIG。
更新规范必须保留来源、适用范围、核验日期和变更理由。
本 Skill 的效果需用相同页面任务进行前后对照，不能凭结构检查声称 UI 已改善。
