# Package validation — 2026-10-22

Scope: packaging, links, example JSON and deterministic data-validator tests.
Not an end-to-end agent benchmark, visual audit, Xcode build, simulator test or Apple Watch test.

- SKILL.md frontmatter fields and name-directory match: passed
- Description within Agent Skills length limit: passed
- Markdown relative-file references: passed
- JSON syntax: passed
- Validator regression tests: 18 passed
- Example spec: passed data checks; target OS/UI Kit remain explicitly unverified

## Test output

```text
test_auto_retry_is_not_an_action (test_validate_screen_spec.SpecTests.test_auto_retry_is_not_an_action) ... ok
test_bad_types_do_not_crash (test_validate_screen_spec.SpecTests.test_bad_types_do_not_crash) ... ok
test_boolean_is_not_a_time (test_validate_screen_spec.SpecTests.test_boolean_is_not_a_time) ... ok
test_cloud_icon_for_device_transfer (test_validate_screen_spec.SpecTests.test_cloud_icon_for_device_transfer) ... ok
test_duplicate_screen (test_validate_screen_spec.SpecTests.test_duplicate_screen) ... ok
test_glass_content (test_validate_screen_spec.SpecTests.test_glass_content) ... ok
test_invalid_date (test_validate_screen_spec.SpecTests.test_invalid_date) ... ok
test_invalid_root_does_not_crash (test_validate_screen_spec.SpecTests.test_invalid_root_does_not_crash) ... ok
test_mutually_exclusive_transcription (test_validate_screen_spec.SpecTests.test_mutually_exclusive_transcription) ... ok
test_not_applying_product_scope_to_other_app (test_validate_screen_spec.SpecTests.test_not_applying_product_scope_to_other_app) ... ok
test_playback_outside_recording (test_validate_screen_spec.SpecTests.test_playback_outside_recording) ... ok
test_pre_receipt_transcription (test_validate_screen_spec.SpecTests.test_pre_receipt_transcription) ... ok
test_progress_requires_evidence (test_validate_screen_spec.SpecTests.test_progress_requires_evidence) ... ok
test_required_action (test_validate_screen_spec.SpecTests.test_required_action) ... ok
test_scope_creep (test_validate_screen_spec.SpecTests.test_scope_creep) ... ok
test_timestamp_outside_recording (test_validate_screen_spec.SpecTests.test_timestamp_outside_recording) ... ok
test_title_drift (test_validate_screen_spec.SpecTests.test_title_drift) ... ok
test_valid_fixture_with_truthful_unknown_versions (test_validate_screen_spec.SpecTests.test_valid_fixture_with_truthful_unknown_versions) ... ok

----------------------------------------------------------------------
Ran 18 tests in 0.002s

OK
```
