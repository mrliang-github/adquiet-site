# screen spec v0.1

本 JSON 用于程序可检查的任务事实，不是 HIG 官方 schema，不替代页面任务卡。

顶层：`product`、`profile`（腕笺为 wristquill），`records` 数组，`screens` 数组。
record：`id`、`title`、`created_at`（ISO 日期时间含时区）、`duration_seconds` 非负数、
`segment_starts_seconds` 升序非负数组，均不得大于 duration。
screen 必填：`id`、`platform`（ios/watchos）、`target_os`、`ui_kit_reference`、`task`、
`entry`、`primary_action`、`state`。未知系统可写 needs_verification，会产生警告而不是伪造数值。

业务数据可选：record_id、playback_seconds、display.title、display.duration_seconds。
state 是不同维度的对象，transcription 如存在必须是一个字符串，不能填多个互斥状态。
通用允许的 transcription 值：not_started、waiting、running、failed、completed。

progress：mode=none/indeterminate/determinate；确定进度应给 evidence，说明可靠工作量来源；
若使用 value，范围 0–1。存在 eta_seconds 时也要 evidence。
仅声明 evidence 不能证明进度真的真实，人工与运行测试仍必需。
icons 为符号名列表；features 为功能标识列表；content_material 可为 standard/liquid-glass。

当 product=wristquill 时，额外检查：queued 转写不得已运行或完成；等待传输不用 cloud 图标；
默认不含摘要/词典/账号/云同步等范围外功能；正文不能设为 liquid-glass。
这些是腕笺约束，不对所有其他产品应用。

一个记录的历史状态和当前状态可以分别展示，但要在画面外说明是状态对照。
脚本不从文字文案推断全部业务语义，仍需人工阅读页面。
