# 官方来源与维护

整理时间：2026-10-22。此文件区分“本轮读到正文”与“保留的查询入口”。
HIG 页面持续变化；资料发布时间、这次核验日期、UI Kit 版本和 App 最低系统不能混同。

## 已核验的设计依据

| ID | 官方来源 | 本轮访问与用途 |
|---|---|---|
| A01 | [Apple Design Resources](https://developer.apple.com/design/resources/) | 资源索引正文；UI Kit 以实际目标版本选取，不随包分发 |
| A02 | [Layout](https://developer.apple.com/design/human-interface-guidelines/layout) | 读取官方 DocC JSON；层级、适配、平台差异 |
| A03 | [Typography](https://developer.apple.com/design/human-interface-guidelines/typography) | 读取官方 DocC JSON；系统文字样式、Dynamic Type |
| A04 | [Color](https://developer.apple.com/design/human-interface-guidelines/color) | 读取官方 DocC JSON；语义色与非颜色提示 |
| A05 | [Accessibility](https://developer.apple.com/design/human-interface-guidelines/accessibility) | 读取官方 DocC JSON；可访问性设计原则，数值不脱离组件上下文 |
| A06 | [Materials](https://developer.apple.com/design/human-interface-guidelines/materials) | 读取官方 DocC JSON；Liquid Glass 的功能层/内容层边界 |
| A07 | [Buttons](https://developer.apple.com/design/human-interface-guidelines/buttons) | 读取官方 DocC JSON；命中区域一般 44×44 pt、熟悉符号、按下状态 |
| A08 | [Progress indicators](https://developer.apple.com/design/human-interface-guidelines/progress-indicators) | 读取官方 DocC JSON；确定/不确定进度及真实表达 |
| A09 | [Onboarding](https://developer.apple.com/design/human-interface-guidelines/onboarding) | 读取官方 DocC JSON；先体验、延后非必要设置、按场景请求权限 |
| A10 | [Designing for watchOS](https://developer.apple.com/design/human-interface-guidelines/designing-for-watchos/) | 官方搜索返回正文；直接页面访问失败/仅 JS，快速任务与浅导航 |
| A11 | [Collaboration and sharing](https://developer.apple.com/design/human-interface-guidelines/collaboration-and-sharing) | 官方搜索返回正文；直接页面仅 JS，系统分享/ShareLink |
| A12 | [Complications](https://developer.apple.com/design/human-interface-guidelines/complications) | 官方搜索返回正文；系统家族、深链、染色与隐私 |
| A13 | [Accessibility framework](https://developer.apple.com/documentation/accessibility/) | 官方搜索返回索引；测试入口，未执行 Inspector |

部分普通 HTML 仅返回 JavaScript 壳。本轮以同站点公开 DocC 内容或官方搜索正文交叉读取，
不是宣称已经使用浏览器打开并测试全部交互示例。DocC 路径不是承诺稳定的公共 API：
`https://developer.apple.com/tutorials/data/design/human-interface-guidelines/<topic>.json`。

## 保留查询入口：本轮不宣称全部读完或已 SDK 验证

| ID | 官方入口 | 使用时机 |
|---|---|---|
| A14 | [SF Symbols](https://developer.apple.com/sf-symbols/) | 核实实际符号、支持系统和使用条件 |
| A15 | [NavigationStack](https://developer.apple.com/documentation/swiftui/navigationstack) | 导航具体 API 与可用性；本轮直接页仅 JS |
| A16 | [ShareLink](https://developer.apple.com/documentation/swiftui/sharelink) | 分享载荷与目标系统；设计建议有 A11 支持 |
| A17 | [Creating accessory widgets and watch complications](https://developer.apple.com/documentation/widgetkit/creating-accessory-widgets-and-watch-complications) | 实现表盘入口，不从图片推断 API |
| A18 | [Performing accessibility testing for your app](https://developer.apple.com/documentation/accessibility/performing-accessibility-testing-for-your-app) | 实现后检查；直接页仅 JS，A13 验证存在入口 |
| A19 | [App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/) | 录音/权限/下载等上线核验；本轮未重新读全量审核条款 |
| A20 | [Adopting Liquid Glass](https://developer.apple.com/documentation/technologyoverviews/adopting-liquid-glass) | 具体系统版本/API 迁移；本包不固定实现方式 |
| A21 | [Lists and tables](https://developer.apple.com/design/human-interface-guidelines/lists-and-tables) | 精确列表规则按页面核查 |
| A22 | [Toolbars](https://developer.apple.com/design/human-interface-guidelines/toolbars) | 精确工具栏位置/溢出按版本核查 |
| A23 | [Sheets](https://developer.apple.com/design/human-interface-guidelines/sheets) | 编辑/临时任务的具体规则 |

## 核验流程

1. 按本页任务选择 2–4 个相关条目，不默认抓取整个 HIG。
2. 精确尺寸、颜色行为、版本、UI Kit、API 能力存在疑问时读取当期官方内容。
3. 正文无法访问时如实标注，优先既有可核验规则，不根据搜索标题扩写。
4. 规则记录：ID、类型、适用平台、来源、核验日、对应测试。
5. Apple 发布新系统、工程升级或出现规则冲突时，人工复核相关部分；不把修改日期当内容全新。
6. 不把社区 Skill 的“全量/合规”自我描述当作权威；它们是索引或经验补充。

## Agent Skills 与安装文档

- [Agent Skills specification](https://agentskills.io/specification)：已读取，SKILL.md + YAML 元数据 + 按需参考文件。
- [OpenAI：Build skills](https://developers.openai.com/plugins/build/skills)：已读取，允许无 MCP 的说明型 Skill。
- [Codex 本地 Skill 文档](https://developers.openai.com/codex/skills/)：本轮重定向到官方 ChatGPT Learn；确认 `.agents/skills` 路径。
- [Claude Code Skills](https://code.claude.com/docs/en/skills)：已读取，`.claude/skills` 及直接调用。
- [Cursor Skills](https://cursor.com/docs/skills)：已读取，`.agents/skills` / `.cursor/skills` 与兼容路径。

## 开源参考：独立项目，非 Apple 官方

| 项目 | 本轮读到的范围 | 取舍 |
|---|---|---|
| [tzzs/apple-design-skill](https://github.com/tzzs/apple-design-skill) | README；SKILL.md 的直接读取未成功 | 接近 HIG 设计参考，README 声明 MIT；不能声称全规则已审计 |
| [raintree-technology/hig-doctor](https://github.com/raintree-technology/hig-doctor) | README；旧 apple-hig-skills 地址重定向至此 | 参考库/扫描器/MCP；README 标记语料快照 2025-02-02，不以仓库更新日期替代规范日期 |
| [AvdLee/SwiftUI-Agent-Skill](https://github.com/AvdLee/SwiftUI-Agent-Skill) | README 与已索引 SKILL.md 部分，直接文件页访问不稳定 | SwiftUI 实现/状态/性能，README 声明 MIT；未安装或运行 |
| [twostraws/SwiftUI-Agent-Skill](https://github.com/twostraws/SwiftUI-Agent-Skill) | README 与 SKILL.md 页面 | SwiftUI 实现/代码审查，MIT；可作为 AvdLee 的替代而非同时必装 |

本包没有复制上述第三方 Skill 代码或整篇规则，也未运行其安装器、MCP 或扫描器。
外部项目的许可与目标版本仍需在实际采用前检查。
