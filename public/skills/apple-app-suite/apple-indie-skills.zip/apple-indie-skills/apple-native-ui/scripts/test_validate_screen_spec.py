"""Small regression suite for screen data checks, not for generated visual quality."""
import copy
import json
from pathlib import Path
import unittest
from validate_screen_spec import validate

BASE = json.loads((Path(__file__).resolve().parents[1] / 'examples' / 'wristquill-screen-spec.json').read_text(encoding='utf-8'))

class SpecTests(unittest.TestCase):
    def setUp(self):
        self.data = copy.deepcopy(BASE)

    def assert_error(self, text):
        errors, _ = validate(self.data)
        self.assertTrue(any(text in e for e in errors), errors)

    def test_valid_fixture_with_truthful_unknown_versions(self):
        errors, warnings = validate(self.data)
        self.assertEqual(errors, [])
        self.assertEqual(len(warnings), 4)

    def test_timestamp_outside_recording(self):
        self.data['records'][0]['segment_starts_seconds'].append(101)
        self.assert_error('timestamp exceeds')

    def test_playback_outside_recording(self):
        self.data['screens'][0]['playback_seconds'] = 120
        self.assert_error('outside recording range')

    def test_title_drift(self):
        self.data['screens'][0]['display']['title'] = '另一个标题'
        self.assert_error('differs from canonical')

    def test_mutually_exclusive_transcription(self):
        self.data['screens'][0]['state']['transcription'] = ['running', 'failed']
        self.assert_error('one valid status')

    def test_pre_receipt_transcription(self):
        self.data['screens'][1]['state']['transcription'] = 'completed'
        self.assert_error('before phone receipt')

    def test_cloud_icon_for_device_transfer(self):
        self.data['screens'][1]['icons'] = ['cloud.arrow.up']
        self.assert_error('cloud icon')

    def test_auto_retry_is_not_an_action(self):
        self.data['screens'][1]['primary_action'] = '稍后自动重试'
        self.assert_error('status text')

    def test_progress_requires_evidence(self):
        self.data['screens'][0]['progress'] = {'mode': 'determinate', 'value': .38}
        self.assert_error('requires evidence')

    def test_scope_creep(self):
        self.data['screens'][0]['features'].append('ai_summary')
        self.assert_error('outside WristQuill')

    def test_not_applying_product_scope_to_other_app(self):
        self.data['product'] = 'other-product'
        self.data['screens'][0]['features'] = ['ai_summary']
        self.assertEqual(validate(self.data)[0], [])

    def test_invalid_root_does_not_crash(self):
        self.assertTrue(validate([])[0])

    def test_bad_types_do_not_crash(self):
        self.data['screens'][0]['record_id'] = []
        self.data['screens'][0]['icons'] = {'icon': 'play'}
        self.data['screens'][1]['state']['transfer'] = []
        self.assert_error('unknown recording')

    def test_invalid_date(self):
        self.data['records'][0]['created_at'] = 'tomorrow'
        self.assert_error('ISO datetime')

    def test_boolean_is_not_a_time(self):
        self.data['records'][0]['duration_seconds'] = True
        self.assert_error('nonnegative finite')

    def test_glass_content(self):
        self.data['screens'][0]['content_material'] = 'liquid-glass'
        self.assert_error('content layer')

    def test_required_action(self):
        self.data['screens'][0].pop('primary_action')
        self.assert_error('primary_action')

    def test_duplicate_screen(self):
        self.data['screens'].append(copy.deepcopy(self.data['screens'][0]))
        self.assert_error('duplicate')

if __name__ == '__main__':
    unittest.main()
