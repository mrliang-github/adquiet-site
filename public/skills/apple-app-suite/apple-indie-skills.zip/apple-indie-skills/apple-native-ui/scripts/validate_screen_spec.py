#!/usr/bin/env python3
"""Check screen-spec data only; not an Apple HIG, image, or runtime validator.

Python 3.9+, standard library only. Reads one explicitly supplied JSON file.
No network calls, installation, project modification, or shell commands.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
from typing import Any


def is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def validate(data: Any) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(data, dict):
        return ['root: must be an object'], []
    if not nonempty(data.get('product')):
        errors.append('product: required nonempty string')
    for key in ('records', 'screens'):
        if not isinstance(data.get(key), list):
            errors.append(f'{key}: must be an array')
    if errors:
        return errors, warnings
    if not data['screens']:
        errors.append('screens: at least one screen is required')
    records: dict[str, dict[str, Any]] = {}
    for i, record in enumerate(data['records']):
        loc = f'records[{i}]'
        if not isinstance(record, dict):
            errors.append(f'{loc}: must be an object')
            continue
        rid = record.get('id')
        if not nonempty(rid):
            errors.append(f'{loc}.id: required nonempty string')
            continue
        if rid in records:
            errors.append(f'{loc}.id: duplicate {rid}')
        records[rid] = record
        if not nonempty(record.get('title')):
            errors.append(f'{loc}.title: required nonempty string')
        created = record.get('created_at')
        try:
            if not isinstance(created, str):
                raise ValueError()
            if datetime.fromisoformat(created.replace('Z', '+00:00')).tzinfo is None:
                raise ValueError()
        except ValueError:
            errors.append(f'{loc}.created_at: ISO datetime with timezone required')
        duration = record.get('duration_seconds')
        valid_duration = is_number(duration) and duration >= 0
        if not valid_duration:
            errors.append(f'{loc}.duration_seconds: nonnegative finite number required')
        starts = record.get('segment_starts_seconds', [])
        if not isinstance(starts, list) or not all(is_number(t) and t >= 0 for t in starts):
            errors.append(f'{loc}.segment_starts_seconds: nonnegative numbers required')
        else:
            if starts != sorted(starts):
                errors.append(f'{loc}: segment starts must be ordered')
            if valid_duration and any(t > duration for t in starts):
                errors.append(f'{loc}: timestamp exceeds duration')
    ids: set[str] = set()
    allowed_transcriptions = {'not_started', 'waiting', 'running', 'failed', 'completed'}
    wristquill = data['product'].lower() == 'wristquill'
    for i, screen in enumerate(data['screens']):
        loc = f'screens[{i}]'
        if not isinstance(screen, dict):
            errors.append(f'{loc}: must be an object')
            continue
        for key in ('id', 'platform', 'target_os', 'ui_kit_reference', 'task', 'entry', 'primary_action'):
            if not nonempty(screen.get(key)):
                errors.append(f'{loc}.{key}: required nonempty string')
        sid = screen.get('id')
        if nonempty(sid):
            if sid in ids:
                errors.append(f'{loc}.id: duplicate {sid}')
            ids.add(sid)
        if screen.get('platform') not in ('ios', 'watchos'):
            errors.append(f'{loc}.platform: supported scope is ios/watchos')
        for key in ('target_os', 'ui_kit_reference'):
            if screen.get(key) == 'needs_verification':
                warnings.append(f'{loc}.{key}: not yet verified')
        state = screen.get('state')
        if not isinstance(state, dict) or not state:
            errors.append(f'{loc}.state: nonempty object required')
            state = {}
        trans = state.get('transcription')
        if trans is not None and (not isinstance(trans, str) or trans not in allowed_transcriptions):
            errors.append(f'{loc}.state.transcription: one valid status string required')
            trans = None
        rid = screen.get('record_id')
        record = records.get(rid) if isinstance(rid, str) else None
        if rid is not None and record is None:
            errors.append(f'{loc}.record_id: unknown recording')
        display = screen.get('display', {})
        if not isinstance(display, dict):
            errors.append(f'{loc}.display: must be an object')
            display = {}
        if record:
            for key in ('title', 'created_at', 'duration_seconds'):
                if key in display and display[key] != record.get(key):
                    errors.append(f'{loc}.display.{key}: differs from canonical recording')
            if 'playback_seconds' in screen:
                t = screen['playback_seconds']
                duration = record.get('duration_seconds')
                if not is_number(t) or t < 0 or (is_number(duration) and t > duration):
                    errors.append(f'{loc}.playback_seconds: outside recording range')
        elif 'playback_seconds' in screen:
            errors.append(f'{loc}: playback requires a known record_id')
        progress = screen.get('progress', {'mode': 'none'})
        if not isinstance(progress, dict):
            errors.append(f'{loc}.progress: must be an object')
            progress = {'mode': 'none'}
        mode = progress.get('mode')
        if mode not in ('none', 'indeterminate', 'determinate'):
            errors.append(f'{loc}.progress.mode: invalid value')
        if mode == 'determinate' or 'eta_seconds' in progress:
            if not nonempty(progress.get('evidence')):
                errors.append(f'{loc}.progress: determinate progress/ETA requires evidence')
        if 'value' in progress and (mode != 'determinate' or not is_number(progress['value']) or not 0 <= progress['value'] <= 1):
            errors.append(f'{loc}.progress.value: requires determinate mode and a number in [0, 1]')
        if 'eta_seconds' in progress and (not is_number(progress['eta_seconds']) or progress['eta_seconds'] < 0):
            errors.append(f'{loc}.progress.eta_seconds: must be a nonnegative number')
        list_fields: dict[str, list[str]] = {}
        for field in ('icons', 'features'):
            value = screen.get(field, [])
            if not isinstance(value, list) or not all(isinstance(x, str) for x in value):
                errors.append(f'{loc}.{field}: must be a string array')
                value = []
            list_fields[field] = value
        if wristquill:
            transfer = state.get('transfer')
            # Use equality rather than set membership to tolerate malformed JSON types.
            pending = transfer == 'queued' or transfer == 'failed'
            if pending and trans in ('running', 'completed'):
                errors.append(f'{loc}: watch audio cannot be transcribed before phone receipt')
            if pending and any('cloud' in icon.lower() for icon in list_fields['icons']):
                errors.append(f'{loc}: cloud icon misrepresents local device transfer')
            if screen.get('primary_action') == '稍后自动重试':
                errors.append(f'{loc}: automatic retry is status text, not a user action')
            forbidden = {'ai_summary', 'personal_dictionary', 'account', 'cloud_sync', 'chat', 'speaker_identification', 'model_tiers'}
            extra = set(list_fields['features']) & forbidden
            if extra:
                errors.append(f'{loc}: outside WristQuill MVP scope: {", ".join(sorted(extra))}')
            if screen.get('content_material') == 'liquid-glass':
                errors.append(f'{loc}: WristQuill content layer must not use liquid-glass')
    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('spec', type=Path)
    parser.add_argument('--json', action='store_true', help='Machine-readable findings')
    args = parser.parse_args()
    try:
        data = json.loads(args.spec.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        parser.exit(2, f'Cannot read screen spec: {exc}\n')
    errors, warnings = validate(data)
    result = {'data_checks_passed': not errors, 'errors': errors, 'warnings': warnings,
              'limitation': 'Data checks only; no image, code, runtime or HIG compliance verification.'}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for item in errors:
            print('ERROR:', item)
        for item in warnings:
            print('WARN:', item)
        print('Data checks:', 'PASS' if not errors else 'FAIL')
        print(result['limitation'])
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
