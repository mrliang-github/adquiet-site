# 参考记录

2026-10-13 阅读：

- [hujjun/mcd-saver-strategist](https://github.com/hujjun/mcd-saver-strategist)，参考提交 [`b2bceb7cf6f188c6ffc047d677d7740b62d3f778`](https://github.com/hujjun/mcd-saver-strategist/commit/b2bceb7cf6f188c6ffc047d677d7740b62d3f778)。
- 阅读其 SKILL.md、optimizer.py、README 和 MIT LICENSE。
- 借鉴：取数/计算/表达分工、门店菜单与账号优惠合并考虑、核价后确认下单、可离线演示。
- 本项目源码与模板重新编写，没有复制其优化器、示例数据或图像；不沿用“必须领取全部券”、缺失营养记零或抽象券规则推导实付的做法。
- [麦当劳官方接口说明](https://open.mcd.cn/mcp/doc) 及 [官方 GitHub](https://github.com/M-China/mcd-mcp-server)。具体字段以运行时 MCP schema/响应为准。

两者未在本项目开发期间做真实下单对比；不能从本地样例推断谁更省钱。
