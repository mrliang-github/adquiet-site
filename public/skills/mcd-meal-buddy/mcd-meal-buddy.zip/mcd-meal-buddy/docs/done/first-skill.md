# 麦麦搭餐第一版

本地实现和离线验证完成；真实连接/交易验证缺口见 `docs/validation.md`，交付状态 preview-only。

## 目标

WorkBuddy 中按位置和新品/汉堡/控热量意图查官方菜单与优惠，给出核价方案，支持改餐、确认后下单以及本地小票。
常规能力全部保留；差异优先体现在意图约束、清楚的取舍和可展示的小票。

## 范围与边界

- SKILL.md 负责意图与 MCP 编排，references 负责条件流程与数据契约。
- Python 标准库脚本校验候选、汇总营养、排序/比较方案、渲染 HTML 小票。交易通过宿主官方 MCP；无独立网络客户端。
- 原创实现，参考 hujjun/mcd-saver-strategist 的取数/计算/表达分工；不复制其抽象券叠加算法。
- 本次不存凭据、不领券、不创建订单，不发布 GitHub。
- 用户机器未发现已配置的麦当劳连接器，因此本次验证范围为离线脚本、Skill 结构和 HTML UI；真实调用单独标记待验证。

## 文件边界

SKILL.md；references/；scripts/meal_plan.py；scripts/receipt.py；examples/；tests/；README.md 和引用说明。

## 验证

1. 三种意图、数量与套餐展开、硬约束/无解、缺失营养、费用单位和过期报价。
2. 改餐使旧请求指纹失效；未核价/跨店/跨渠道不能作为有效候选。
3. HTML 注入、敏感字段不进入分享页、订单状态不能从 demo 变成真实。
4. Ego 桌面与手机宽度检查，所有执行通过 workflow-runner 并核对清理。
5. 链接安装 WorkBuddy/通用 skills 目录，验证链接与结构，创建本地 commit。
