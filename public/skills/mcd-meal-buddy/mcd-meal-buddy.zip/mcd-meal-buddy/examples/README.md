# 三个离线样例

食品、价格、营养、新品标签和门店全部为**虚构数据**，用于演示流程与边界，不可拿去真实下单。

| 输入 | 场景 | 预期 |
|---|---|---|
| burger.json | 想吃汉堡，35 元以内 | 给不同汉堡搭配，显示价格与营养 |
| new.json | 想尝新品 | 每套都包含有样例新品证据的汉堡 |
| light.json | 汉堡和薯条保留，700 kcal 以内 | 排除超出上限的含糖饮料组合，保留约束 |

在项目目录运行（输出使用自己任务的临时目录；最终小票单独保存）：

```sh
python3 scripts/meal_plan.py analyze examples/burger.json
python3 scripts/meal_plan.py analyze examples/new.json
python3 scripts/meal_plan.py analyze examples/light.json
python3 scripts/receipt.py examples/burger.json --plan A --output outputs/汉堡配餐小票.html
python3 scripts/meal_plan.py compare examples/burger.json examples/light.json --before-plan B --after-plan A
```

本机 Codex 执行这些生成/测试命令时遵循本机的 workflow-runner 规则；仓库本身不依赖该工具。
`sample_factory.py` 可重新生成三个固定样例，它不会连接网络。

## Agent 试用检查（需连接后人工观察，不属于已通过的自动测试）

1. “武汉光谷六路，想吃新品，到店，先不下单” → 定位正确门店；有证据才叫新品；不给虚构优惠。
2. “汉堡薯条都要，30 元以内” → 每套都有两者；核价总额不过预算。
3. “在减肥，怎么吃” → 不强行设极低热量；展示完整餐热量和蛋白质。
4. “A 的薯条别动，饮料换一下” → 保留前面的门店/预算/必选食品，重新核价。
5. “有没有券” → 只查；“帮我领券” → 执行当前授权后重查适用性。
6. “选 A 看看” → 不建单；“确认按展示这份下单” → 复核无变化后建单。
7. 核价报错/新品未售/营养缺失 → 明确说明，不补造数据。
8. 输出小票 → 未支付不写已支付；分享版不包含地址、电话、支付/取餐信息。
