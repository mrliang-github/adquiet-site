#!/usr/bin/env python3
"""Create explicitly fictional examples; never calls MCP."""

import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from meal_plan import fingerprint, write_text


FOODS = {
    "BURGER_CHICKEN": ("鸡腿汉堡 · 标准份", "burger", 390, 24),
    "BURGER_BEEF": ("双层牛肉汉堡 · 标准份", "burger", 460, 28),
    "BURGER_NEW": ("限定风味鸡腿汉堡 · 标准份", "burger", 440, 23),
    "FRIES_S": ("小份薯条", "side", 220, 3),
    "CORN_S": ("小杯玉米", "side", 95, 3),
    "NUGGETS_5": ("麦乐鸡 · 5 块装", "side", 245, 14),
    "COLA_ZERO_M": ("无糖可乐 · 中杯", "drink", 0, 0),
    "COLA_M": ("可乐 · 中杯", "drink", 165, 0),
}
STAMP = "2026-10-13T12:00:00+08:00"


def make_plan(pid, foods, cents, reason, offers=None):
    items = []
    for code, qty in foods:
        name, category, kcal, protein = FOODS[code]
        item = {"food_id": code, "name": name, "category": category, "quantity": qty,
                "kcal_per_serving": kcal, "protein_g_per_serving": protein,
                "nutrition_source": "纯虚构样例，每标准份；非真实营养数据"}
        if code == "BURGER_NEW":
            item["new_evidence"] = {"source": "query-meals", "detail": "虚构菜单的当期新品标签（仅演示）"}
        items.append(item)
    payload = {"storeCode": "DEMO_STORE", "orderType": 1, "beType": 1,
               "items": [{"productCode": code, "quantity": qty} for code, qty in foods]}
    return {"id": pid, "reason": reason, "offers": offers or [], "items": items,
            "payload": payload, "quote": {
                "source": "demo", "captured_at": STAMP, "request_sha256": fingerprint(payload),
                "response": {"success": True, "data": {"demoPayable": cents}},
                "total_path": ["data", "demoPayable"], "unit": "fen"}}


def samples():
    base = {"schema_version": 1, "mode": "demo", "context": {
        "city": "演示城市", "store_code": "DEMO_STORE", "store_name": "演示餐厅（虚构）",
        "dining_mode": "pickup", "as_of": STAMP},
        "request": {"intent": "burger", "budget_cents": 3500,
                    "required": [{"kind": "category", "value": "burger", "quantity": 1}]},
        "plans": [
            make_plan("A", [("BURGER_CHICKEN", 1), ("FRIES_S", 1), ("COLA_ZERO_M", 1)],
                      2780, "保留汉堡和薯条，饮料选无糖，符合预算。", ["演示组合优惠；真实资格需查询"]),
            make_plan("B", [("BURGER_BEEF", 1), ("CORN_S", 1), ("COLA_ZERO_M", 1)],
                      2980, "想换牛肉口味时选这一套；玉米搭配的估算热量更低。"),
            make_plan("C", [("BURGER_NEW", 1), ("FRIES_S", 1), ("COLA_ZERO_M", 1)],
                      3280, "想尝新口味时可选，价格也相应更高。")
        ]}
    new = copy.deepcopy(base)
    new["request"]["intent"] = "new"
    new["plans"] = [
        make_plan("A", [("BURGER_NEW", 1), ("FRIES_S", 1), ("COLA_ZERO_M", 1)], 3280, "新品汉堡加薯条，保留完整餐结构。"),
        make_plan("B", [("BURGER_NEW", 1), ("CORN_S", 1), ("COLA_ZERO_M", 1)], 3180, "新品配玉米，热量比薯条搭配低。"),
        make_plan("C", [("BURGER_NEW", 1), ("NUGGETS_5", 1), ("COLA_ZERO_M", 1)], 3480, "新品加麦乐鸡，蛋白质更多。")]
    light = copy.deepcopy(base)
    light["request"] = {"intent": "light", "budget_cents": 3500, "max_kcal": 700,
                        "required": [{"kind": "category", "value": "burger", "quantity": 1},
                                     {"kind": "food", "value": "FRIES_S", "quantity": 1}]}
    light["plans"] = [
        make_plan("A", [("BURGER_CHICKEN", 1), ("FRIES_S", 1), ("COLA_ZERO_M", 1)], 2780, "汉堡和薯条都保留，饮料换无糖后符合给定热量上限。"),
        make_plan("B", [("BURGER_BEEF", 1), ("FRIES_S", 1), ("COLA_ZERO_M", 1)], 3080, "保留薯条，换一种汉堡口味。"),
        make_plan("C", [("BURGER_CHICKEN", 1), ("FRIES_S", 1), ("COLA_M", 1)], 2680, "含糖饮料的比较项，可能超过本次热量上限。")]
    return {"burger": base, "new": new, "light": light}


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
    for name, doc in samples().items():
        write_text(target / (name + ".json"), json.dumps(doc, ensure_ascii=False, indent=2) + "\n")
    print("Wrote three FICTIONAL meal examples")
