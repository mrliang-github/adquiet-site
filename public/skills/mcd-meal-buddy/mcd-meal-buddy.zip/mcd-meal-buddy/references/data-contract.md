# 本地数据契约 v1

完整可运行样例在 `examples/*.json`，均为虚构数据。真实 session/analysis 放在私有目录，权限 0600，勿提交。

## Session

| 字段 | 意义 |
|---|---|
| schema_version | 固定 1 |
| mode | `demo` 或 `live`，演示数据不可改标签冒充真实 |
| context | city、store_code、store_name、dining_mode (`pickup`/`delivery`)、as_of（本轮服务器/实际采集时间，含时区） |
| request | intent (`new`/`burger`/`light`/`general`)、可选 budget_cents / max_kcal / required / preferred_food_ids / excluded_food_ids |
| plans | 已构造并分别核价的候选列表 |
| order | 可选，选定方案的 query-order 状态摘录，仅用于纪念小票 |

外送 `context.address_confirmed=true` 表示用户已选择具体地址。地址等私有业务字段只留在必要的核价请求中。
每次对话修改或要创建订单时刷新 `as_of` 并重新核价。脚本不读取服务器时间；历史文件保持其采集时刻，仅可当历史快照。

required 是数组，例如：

```json
[{"kind":"category","value":"burger","quantity":1},
 {"kind":"food","value":"FRIES_M","quantity":1}]
```

相同约束应合并为总数量；food_id 表示具体食品、规格、配方，换规格或特制时分配不同 food_id。
`preferred_food_ids` 仅用于同等硬约束下优先保留喜好，不等于随意增加食物。

## Plan

- `id`：本轮唯一字符串（A/B/C）。
- `reason`：面向用户的一句推荐理由，可能含私人偏好，默认不进入分享小票。
- `offers`：面向用户的优惠条件说明，只写券名称/适用条件，不写券码或支付链接。
- `payload`：用于 `calculate-price` 的实际完整参数，含 storeCode/orderType/beType/items；套餐 roundList、特制、数量等必须与展示清单一致。
- `items`：最终吃到的叶子食品列表，父套餐不再计热量。
- `quote`：绑定 payload 的成功核价响应，不能用菜单原价替代。

叶子食品：`food_id`、`name`（完整名称与规格）、`category`、`quantity`（总份数）、`kcal_per_serving`、`protein_g_per_serving`、`nutrition_source`。
营养未知用 null，不用 0。标准杯与大杯分开；“五块麦乐鸡”是一份，不能把每份营养乘以五再乘数量。
有新品证据的食品额外写 `new_evidence={"source":"query-meals","detail":"某日目标门店的当期新品标签"}`，也支持 query-meal-detail/campaign-calendar；后者须已与目标门店菜单交叉验证。

## Quote

```json
{
  "source": "calculate-price",
  "captured_at": "2026-10-13T12:00:00+08:00",
  "request_sha256": "通过 fingerprint 子命令生成的请求摘要",
  "response": {"success": true, "data": {"实际总应付字段": "29.80"}},
  "total_path": ["data", "实际总应付字段"],
  "unit": "yuan"
}
```

这是契约示意，不是当前官方字段定义。`response` 保留相关响应对象，`total_path` 必须从真实响应和 schema 中选，`unit` 必须核实。
纯演示 quote.source=demo；live 中出现 demo 来源会被拒绝。
相对 context.as_of 超过 10 分钟的报价会被排除，临近下单仍须重查。

```sh
python3 scripts/meal_plan.py fingerprint payload.json
python3 scripts/meal_plan.py analyze session.json --output analysis.json
```

输出含推荐 plans、通过检查的 accepted、剔除原因 rejected。没有合规方案时 needs_relaxation=true，不自动放宽条件。
价格重复方案按最终食品/规格/份数去重，只留低价买法；同名套餐的子项必须先正确展开。

排序：先硬约束；light 优先已知整餐热量更低，否则优先命中用户明确软偏好，再比较总价。
最多显示首推和两个有不同取舍的方案。不足三个时不凑数。这是有限候选排序，不是全菜单优化器。

## 改餐比较

修改后的 payload 必须重新调用核价并绑定新指纹。食品列表、营养映射和用户约束一起更新。

```sh
python3 scripts/meal_plan.py compare before.json after.json --before-plan A --after-plan A
```

输出新减旧的价格/营养差额、增减食品份数、是否同店同渠道。不能把删掉食物或更换门店产生的差额描述成同款省钱。

## 订单状态与小票

没有 order 时生成未下单预览；demo 永远显示演示标签。
`order` 必须包含 `plan_id`、`request_sha256`、`source=query-order`、`observed_at`、`status_text`。
`status_text` 原样摘录同一订单的官方状态，不从“已建单”推断“已支付”。这些元数据由 Agent 填写，脚本只能检查结构与绑定，不能认证其真实性。
HTML 从白名单字段渲染，不嵌入 session 原文；默认不显示门店名称、用户原话、推荐理由原文或任何交易编号。`--private` 增加门店名和推荐理由，仍不输出支付/取餐字段。
