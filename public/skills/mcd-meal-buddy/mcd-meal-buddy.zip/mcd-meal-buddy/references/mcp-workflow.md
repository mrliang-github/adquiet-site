# MCP 调用与证据

官方资料：<https://open.mcd.cn/mcp/doc>；<https://github.com/M-China/mcd-mcp-server>。
工具的参数以客户端当次返回的 schema 为准，以下是调用顺序而非完整 API schema。

## 查询

| 阶段 | 工具 | 要保留的证据 |
|---|---|---|
| 时间 | now-time-info | 当天日期和餐段 |
| 到店 | query-nearby-stores | 目标门店编码、名称、营业与可点餐状态 |
| 外送 | delivery-query-addresses → delivery-query-stores | 用户选中的地址、对应可配送门店；地址只放私有状态 |
| 菜单 | query-meals → query-meal-detail | 当前可售、规格、选项、套餐轮次、配料修改、随单购条件 |
| 优惠 | available-coupons / query-my-coupons / query-store-coupons | 可领、已拥有、门店与渠道适用性，分开记录 |
| 新品 | campaign-calendar + query-meals / query-meal-detail | 当前活动日期/官方新品标签，且目标门店可售；名字里有“新”不足为证 |
| 营养 | list-nutrition-foods | 对应名称、份量、energyKcal、protein 等；可能返回 TOON 文本 |
| 核价 | calculate-price | 实际请求参数、完整成功响应、总应付字段路径、明确的货币单位、查询时间 |

到店通常用 `beType=1`、`orderType=1`，外送通常为 2；不要把这个摘要替代运行时 schema。
组合商品需要 `roundList` 及轮次/子项/规格，不能只传几个 productCode 就认定套餐已选完。
相同父套餐的不同选择需要保留为独立项目。普通商品数量也必须保留。

## 营养与价格归一化

- 菜单名称与营养表名称可能不同，需结合产品/份量证据匹配；不能用模糊相似名字直接当精确营养。
- 一条营养数据是“每份”还是“每 100g”先读说明，再按实际份量换算；无法确认时设 null。
- 展开套餐只汇总叶子食品；重复套餐按总数量相乘，同一食品出现两次也要计两次。
- 调料移除若没有量化营养依据，保留标准配方估算并说明；不能凭空扣掉若干热量。
- 核价接口与订单接口的货币单位可能不同。官方文档中的字符串金额与实测响应可能采用不同单位，必须读当次 schema/响应说明；禁止凭数值大小猜元或分。
- 在 `quote.total_path` 指向总应付字段，显式设置 `unit=fen|yuan`；代码使用 Decimal 转成整数分。配送、餐具费等已经包括在总应付里，不再重复相加。
- 同餐不同券/套餐买法各调用核价。券数量、叠加是否允许由官方算价结果判断，不在本地编造通用规则。

## 请求指纹与局限

`meal_plan.py fingerprint payload.json` 对完整核价参数生成 SHA-256。调用核价前记下指纹，成功响应与该指纹绑定。
套餐选项、数量、门店、地址、渠道、券改变后，旧指纹不再适用。代码能发现状态文件与已记录请求不一致，不能证明 Agent 没有抄错原始响应。
Agent 仍须核对：可见食品列表与真实请求一致、报价字段及单位正确、营养匹配可靠。
本地检查和离线测试不能代替 MCP 端到端验证。

## 交易

下单前再次核价并检查 `takeWayCode` 等返回字段。用户明确确认的对象必须包含门店、渠道、餐品和总额。
把核价参数按 create-order schema 转换，而非盲目原样拷贝；保留业务所需的商品和 roundList 等内容。
未知结果先调用订单列表/详情核实；不要重复提交。官方支付/取餐入口在对话里提供，不能写进分享小票。
`create-order` 成功通常为待支付。`query-order` 返回的 `orderStatus` 是显示依据，不跨点餐/商城业务猜测状态码。
小票可以附上 `order.status_text`，它只是 Agent 从订单响应摘录的状态，脚本不连接支付系统核验。
