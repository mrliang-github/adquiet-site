# 接入与安装

本 Skill 需要能执行 Python 3.9+ 脚本的 Agent 宿主，以及用户自己的麦当劳官方 MCP 连接。
本地脚本只用 Python 标准库；不内置网络客户端或凭据。

## WorkBuddy

1. 把本项目目录放入 `~/.workbuddy/skills/mcd-meal-buddy/`，目录里必须直接有 `SKILL.md`。
2. 在 WorkBuddy 的连接器中添加官方 MCP；界面路径可能随版本变化，以客户端当前界面为准。
3. 到 [麦当劳开放平台](https://open.mcd.cn/mcp) 使用自己的手机号登录、激活 Token，在连接器配置中填写。
4. 使用 Streamable HTTP，地址为 `https://mcp.mcd.cn`；Authorization 请求头为 `Bearer` 加用户自己的 Token。
5. Token 只放在用户自己管理的宿主凭据配置中，不发给 Agent、不写进本项目、不上传仓库。示例配置见 `mcp-config.example.json`。
6. 保存后，在新对话中输入下方需求；若当前对话没重新发现 Skill，重开对话或刷新技能列表。

先用 `now-time-info` 或营养查询检查连接。配置存在不等于 MCP 已连通；401/403 时交给用户检查登录或 Token，勿循环重试。

## 试用语句

> 用麦麦搭餐。我在武汉光谷六路，1 人，到店，想吃汉堡，30 元以内，帮我选几套，列价格和估算热量，先不下单。

> 我想尝新品，饮料要无糖，先看看附近这家店有哪些。

> 我最近在控制热量，但汉堡和薯条都想保留，帮我调整其他部分。

> A 方案的薯条留着，饮料换无糖的，重新算一下，再生成配餐小票。

## 其他客户端

支持 SKILL.md 与本地脚本的宿主可使用同一目录，例如 `~/.agents/skills/mcd-meal-buddy/`。
工具名可以有服务前缀，但服务来源必须是用户已配置的官方 MCP。

## 免连接体验

运行 `examples/README.md` 的离线样例。样例展示输出格式，不证明真实价格、优惠或下单可用。
