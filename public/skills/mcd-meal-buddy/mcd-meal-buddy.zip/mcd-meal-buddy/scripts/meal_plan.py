#!/usr/bin/env python3
"""Check and rank MCP-priced meal candidates. No network or transaction code."""

import argparse
import hashlib
import json
import math
import os
from collections import Counter
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path


class PlanError(ValueError):
    pass


def fingerprint(payload):
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                     allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def reject_credentials(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in {"authorization", "token", "access_token", "mcd_mcp_token",
                               "password", "cookie", "api_key", "secret"}:
                raise PlanError("输入不能包含凭据；仅使用不含认证信息的业务数据")
            reject_credentials(item)
    elif isinstance(value, list):
        for item in value:
            reject_credentials(item)
    elif isinstance(value, str) and value.lower().startswith("bearer "):
        raise PlanError("输入不能包含 Bearer 凭据")


def read_json(path):
    path = Path(path)
    if path.stat().st_size > 4 * 1024 * 1024:
        raise PlanError("输入超过 4 MiB，请仅保留本次候选所需数据")
    try:
        value = json.loads(path.read_text(encoding="utf-8"),
                           parse_constant=lambda _: (_ for _ in ()).throw(PlanError("非法数值")))
    except json.JSONDecodeError:
        raise PlanError("输入不是有效 JSON") from None
    reject_credentials(value)
    return value


def write_text(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0)
    if path.is_symlink():
        raise PlanError("输出文件不能是符号链接")
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write(text)


def number(value, label, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PlanError(label + " 必须是非负数")
    if not math.isfinite(value) or value < 0 or (integer and int(value) != value):
        raise PlanError(label + " 数值不合法")
    return int(value) if integer else float(value)


def moment(value):
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if result.tzinfo is None:
            raise ValueError()
        return result
    except (AttributeError, TypeError, ValueError):
        raise PlanError("时间必须是含时区的 ISO 8601 格式") from None


def amount_in_cents(value, unit):
    if isinstance(value, bool) or unit not in {"fen", "yuan"}:
        raise PlanError("核价必须明确 unit=fen 或 yuan")
    try:
        amount = Decimal(str(value)) * (100 if unit == "yuan" else 1)
        if not amount.is_finite() or amount < 0 or amount != amount.to_integral_value():
            raise ValueError()
        return int(amount)
    except (InvalidOperation, ValueError):
        raise PlanError("核价金额不能准确转换成整数分") from None


def quote_total(plan, context, mode):
    payload, quote = plan["payload"], plan["quote"]
    if str(payload.get("storeCode")) != str(context["store_code"]):
        raise PlanError("核价门店与当前门店不一致")
    channel = {"pickup": (1, 1), "delivery": (2, 2)}[context["dining_mode"]]
    if (payload.get("orderType"), payload.get("beType")) != channel:
        raise PlanError("核价取餐方式与当前方式不一致")
    if context["dining_mode"] == "delivery" and not context.get("address_confirmed"):
        raise PlanError("外送地址尚未由用户确定")
    if not isinstance(payload.get("items"), list) or not payload["items"]:
        raise PlanError("核价缺少商品列表")
    for item in payload["items"]:
        if not item.get("productCode") or number(item.get("quantity"), "商品数量", True) < 1:
            raise PlanError("核价商品必须有编码和正整数数量")
    if quote.get("request_sha256") != fingerprint(payload):
        raise PlanError("餐单已变化，旧核价失效，请重新算价")
    expected = "demo" if mode == "demo" else "calculate-price"
    if quote.get("source") != expected:
        raise PlanError("演示与真实核价来源不匹配")
    age = (moment(context["as_of"]) - moment(quote["captured_at"])).total_seconds()
    if age < -60 or age > 600:
        raise PlanError("核价时间不匹配或已超过 10 分钟，请重新核价")
    if quote["response"].get("success") is not True:
        raise PlanError("官方核价未成功")
    path = quote.get("total_path")
    if not isinstance(path, list) or not path or not all(isinstance(k, str) for k in path):
        raise PlanError("缺少总应付字段路径")
    value = quote["response"]
    for key in path:
        value = value[key]
    return amount_in_cents(value, quote.get("unit"))


def food_totals(items):
    if not isinstance(items, list) or not items:
        raise PlanError("没有实际餐品")
    totals = {"kcal": Decimal(0), "protein_g": Decimal(0)}
    missing = {"kcal": [], "protein_g": []}
    foods, categories = Counter(), Counter()
    for item in items:
        if not all(isinstance(item.get(k), str) and item[k].strip()
                   for k in ("food_id", "name", "category")):
            raise PlanError("餐品缺少食品编号、完整名称或类别")
        qty = number(item.get("quantity"), "食品份数", True)
        if qty < 1:
            raise PlanError("食品份数必须大于零")
        foods[item["food_id"]] += qty
        categories[item["category"]] += qty
        for key in totals:
            value = item.get(key + "_per_serving")
            if value is None:
                missing[key].append(item["name"])
            else:
                number(value, key)
                if not item.get("nutrition_source"):
                    raise PlanError("有营养数值但缺少份量/数据来源")
                totals[key] += Decimal(str(value)) * qty
    nutrition = {}
    for key, total in totals.items():
        nutrition[key] = None if missing[key] else round(float(total), 1)
        nutrition["known_" + key] = round(float(total), 1)
        nutrition["missing_" + key] = list(dict.fromkeys(missing[key]))
    return nutrition, foods, categories


def check_plan(plan, context, request, mode):
    total = quote_total(plan, context, mode)
    nutrition, foods, categories = food_totals(plan["items"])
    for constraint in request.get("required", []):
        kind = constraint["kind"]
        if kind not in {"food", "category"}:
            raise PlanError("required.kind 仅支持 food 或 category")
        counts = foods if kind == "food" else categories
        minimum = number(constraint.get("quantity", 1), "必选份数", True)
        if minimum < 1 or counts[constraint["value"]] < minimum:
            raise PlanError("缺少必须保留的餐品或份数")
    if set(request.get("excluded_food_ids", [])) & set(foods):
        raise PlanError("包含用户不吃的餐品")
    if request["intent"] == "burger" and categories["burger"] < 1:
        raise PlanError("想吃汉堡的方案必须包含汉堡")
    if request["intent"] == "new" and not any(
        isinstance(i.get("new_evidence"), dict)
        and i["new_evidence"].get("source") in {"query-meals", "query-meal-detail", "campaign-calendar"}
        and i["new_evidence"].get("detail")
        for i in plan["items"]
    ):
        raise PlanError("缺少当期官方新品证据")
    budget = request.get("budget_cents")
    if budget is not None and total > number(budget, "预算", True):
        raise PlanError("超过预算（按完整应付总额）")
    cap = request.get("max_kcal")
    if cap is not None:
        number(cap, "热量上限")
        if nutrition["kcal"] is None:
            raise PlanError("营养不全，不能确认符合热量上限")
        if nutrition["kcal"] > cap:
            raise PlanError("超过热量上限")
    preferred = set(request.get("preferred_food_ids", []))
    return {
        "id": plan["id"], "reason": plan.get("reason", ""),
        "total_cents": total, "nutrition": nutrition, "items": plan["items"],
        "offers": plan.get("offers", []), "preference_matches": len(preferred & set(foods)),
        "request_sha256": plan["quote"]["request_sha256"],
        "composition": sorted(foods.items()),
    }


def analyze(document):
    reject_credentials(document)
    if document.get("schema_version") != 1 or document.get("mode") not in {"live", "demo"}:
        raise PlanError("要求 schema_version=1 且 mode=live|demo")
    context, request = document["context"], document["request"]
    if context.get("dining_mode") not in {"pickup", "delivery"}:
        raise PlanError("当前版本支持 pickup 和 delivery")
    moment(context["as_of"])
    if request.get("intent") not in {"new", "burger", "light", "general"}:
        raise PlanError("未知吃饭意图")
    accepted, rejected, ids = [], [], set()
    for plan in document["plans"]:
        pid = plan.get("id")
        if not isinstance(pid, str) or not pid or pid in ids:
            raise PlanError("方案 ID 必须非空且唯一")
        ids.add(pid)
        try:
            accepted.append(check_plan(plan, context, request, document["mode"]))
        except (PlanError, KeyError, TypeError) as error:
            detail = str(error) if isinstance(error, PlanError) else "候选数据缺少必要字段或类型不正确"
            rejected.append({"id": pid, "reason": detail})
    # One visible meal can have several quoted buying paths; retain its cheapest path.
    unique = {}
    for plan in sorted(accepted, key=lambda p: (p["total_cents"], p["id"])):
        unique.setdefault(tuple(map(tuple, plan["composition"])), plan)
    pool = list(unique.values())

    def kcal_key(p):
        value = p["nutrition"]["kcal"]
        return float("inf") if value is None else value

    def fit_key(p):
        if request["intent"] == "light":
            return kcal_key(p), -p["preference_matches"], p["total_cents"], p["id"]
        return -p["preference_matches"], p["total_cents"], kcal_key(p), p["id"]

    pool.sort(key=fit_key)
    picked = []

    def add(plan, label):
        if plan["id"] not in {p["id"] for p in picked} and len(picked) < 3:
            picked.append(dict(plan, label=label))

    if pool:
        best = pool[0]
        add(best, "首推")
        cheapest = min(pool, key=lambda p: (p["total_cents"], p["id"]))
        lighter = min(pool, key=lambda p: (kcal_key(p), p["total_cents"], p["id"]))
        if cheapest["total_cents"] < best["total_cents"]:
            add(cheapest, "更省钱")
        if kcal_key(lighter) < kcal_key(best):
            add(lighter, "热量更低")
        for plan in pool:
            add(plan, "换个口味")
    return {
        "schema_version": 1, "mode": document["mode"], "context": context,
        "intent": request["intent"], "plans": picked, "accepted": accepted,
        "rejected": rejected, "candidate_count": len(document["plans"]),
        "scope": "仅比较本次已核价的候选；营养按实际单品份量估算",
        "needs_relaxation": not bool(picked),
    }


def select(report, plan_id):
    for plan in report["accepted"]:
        if plan["id"] == plan_id:
            return plan
    raise PlanError("指定方案没有通过检查")


def compare(before, before_id, after, after_id):
    if before["mode"] != after["mode"]:
        raise PlanError("不能把演示与真实方案比较")
    old, new = select(before, before_id), select(after, after_id)
    old_foods, new_foods = dict(old["composition"]), dict(new["composition"])
    changes = []
    names = {i["food_id"]: i["name"] for p in (old, new) for i in p["items"]}
    for key in sorted(set(old_foods) | set(new_foods)):
        delta = new_foods.get(key, 0) - old_foods.get(key, 0)
        if delta:
            changes.append({"food_id": key, "name": names[key], "quantity_delta": delta})
    nutrition = {}
    for key in ("kcal", "protein_g"):
        a, b = old["nutrition"][key], new["nutrition"][key]
        nutrition[key + "_delta"] = None if a is None or b is None else round(b - a, 1)
    same_context = all(before["context"].get(k) == after["context"].get(k)
                       for k in ("store_code", "dining_mode"))
    return {"price_delta_cents": new["total_cents"] - old["total_cents"],
            "same_store_and_channel": same_context, "changes": changes, **nutrition,
            "note": "差额为新方案减旧方案；餐品或条件变化时不要称为同款节省"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    fp = sub.add_parser("fingerprint")
    fp.add_argument("payload")
    ap = sub.add_parser("analyze")
    ap.add_argument("input")
    ap.add_argument("--output")
    cp = sub.add_parser("compare")
    cp.add_argument("before")
    cp.add_argument("after")
    cp.add_argument("--before-plan", required=True)
    cp.add_argument("--after-plan", required=True)
    args = parser.parse_args()
    try:
        if args.command == "fingerprint":
            print(fingerprint(read_json(args.payload)))
            return
        if args.command == "analyze":
            result = analyze(read_json(args.input))
        else:
            result = compare(analyze(read_json(args.before)), args.before_plan,
                             analyze(read_json(args.after)), args.after_plan)
        output = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if getattr(args, "output", None):
            write_text(args.output, output)
            print(json.dumps({"output": str(Path(args.output).resolve()),
                              "plans": len(result["plans"]),
                              "rejected": len(result["rejected"])}, ensure_ascii=False))
        else:
            print(output, end="")
    except (PlanError, OSError, KeyError, TypeError) as error:
        message = str(error) if isinstance(error, PlanError) else "读取失败或数据结构不符合契约"
        parser.exit(2, message + "\n")


if __name__ == "__main__":
    main()
