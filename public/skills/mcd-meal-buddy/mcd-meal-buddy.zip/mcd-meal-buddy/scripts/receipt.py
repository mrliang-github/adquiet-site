#!/usr/bin/env python3
"""Render a self-contained, escaped, share-safe meal receipt."""

import argparse
import base64
import hashlib
import html
import re
from pathlib import Path

from meal_plan import PlanError, analyze, moment, read_json, select, write_text


def safe(value):
    return html.escape(str(value), quote=True)


def public_text(value):
    value = re.sub(r"https?://\S+|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", "[已隐藏]", str(value))
    value = re.sub(r"(?i)bearer\s+\S+|\b1[3-9]\d{9}\b|\b[A-Za-z0-9_-]{24,}\b", "[已隐藏]", value)
    return safe(value)


def status_for(document, plan):
    if document["mode"] == "demo":
        return "演示 · 配餐预览", "全部为虚构样例，不代表真实价格、营养或订单。"
    order = document.get("order")
    if not order:
        return "配餐预览 · 未下单", "本次核价结果；价格和供应可能变化，下单前会再次核对。"
    if (order.get("plan_id") != plan["id"]
            or order.get("request_sha256") != plan["request_sha256"]
            or order.get("source") != "query-order"):
        raise PlanError("订单状态必须来自同一方案的 query-order 记录")
    moment(order.get("observed_at"))
    status = order.get("status_text")
    if not isinstance(status, str) or not status.strip() or len(status) > 30:
        raise PlanError("请摘录官方订单状态，不能自行猜测")
    return "订单状态 · " + status, "状态为查询时官方返回的记录；本页是点餐纪念小票，不是发票。"


def render(document, plan_id, private=False):
    report = analyze(document)
    plan = select(report, plan_id)
    status, notice = status_for(document, plan)
    context, nutrition = report["context"], plan["nutrition"]
    intents = {"new": "今天，尝点新鲜的", "burger": "今天，就想吃汉堡", "light": "今天，吃得轻一点", "general": "今天，好好吃一餐"}
    intent = intents[report["intent"]]
    label = next((p["label"] for p in report["plans"] if p["id"] == plan_id), "我的选择")
    total = f"{plan['total_cents'] / 100:.2f}"
    kcal = (f"{nutrition['kcal']:g}" if nutrition["kcal"] is not None
            else f"{nutrition['known_kcal']:g} + ?")
    protein = (f"{nutrition['protein_g']:g}" if nutrition["protein_g"] is not None else "未完整收录")
    stamp = moment(context["as_of"]).strftime("%Y.%m.%d")
    channel = {"pickup": "到店取餐", "delivery": "外送"}[context["dining_mode"]]
    rows = []
    for i, item in enumerate(plan["items"], 1):
        value = item.get("kcal_per_serving")
        calories = "热量未收录" if value is None else f"约 {value * item['quantity']:g} kcal"
        rows.append(f'<li><span class="line-number">{i:02d}</span><div class="food"><strong>{public_text(item["name"])}</strong><small>{safe(calories)}</small></div><span class="qty">× {item["quantity"]}</span></li>')
    offers = "".join(f'<li>{public_text(o)}</li>' for o in plan.get("offers", []))
    offer_section = f'<section class="offers"><span class="eyebrow">本次优惠条件</span><ul>{offers}</ul></section>' if offers else ""
    missing = nutrition["missing_kcal"]
    missing_note = ("以下餐品热量未收录：" + "、".join(missing) + "。上方仅为已知部分，无法确认整餐热量。"
                    if missing else "按所选单品与份数汇总的营养估算，实际制作可能有差异。")
    private_line = (f'<p class="store">{safe(context.get("store_name", ""))}</p>' if private else "")
    reasons = {"new": "围绕当期新品搭配，保留你明确提出的要求。",
               "burger": "汉堡是主角，价格和营养一起看。",
               "light": "在保留想吃的餐品后，比较整餐热量。",
               "general": "把想吃的、预算和可用优惠放在一起考虑。"}
    reason = safe(plan.get("reason", "")) if private else reasons[report["intent"]]
    script = 'document.getElementById("print-receipt").addEventListener("click",()=>window.print());'
    script_hash = base64.b64encode(hashlib.sha256(script.encode()).digest()).decode()
    csp = f"default-src 'none'; style-src 'unsafe-inline'; script-src 'sha256-{script_hash}'; base-uri 'none'; form-action 'none'"
    mode_note = "演示数据 · 可离线体验" if report["mode"] == "demo" else "个人点餐记录 · 非官方产品"
    return f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="{safe(csp)}"><title>麦麦搭餐 · 我的这一餐</title>
<style>
:root{{--ink:#27241e;--muted:#726d63;--paper:#fffdf7;--accent:#edb731;--rule:#d6d0c4}}
*{{box-sizing:border-box}}body{{margin:0;background:#e8e4da;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;-webkit-font-smoothing:antialiased}}
.layout{{max-width:1060px;margin:0 auto;padding:64px 40px;display:grid;grid-template-columns:1fr 430px;gap:76px;align-items:start}}
.intro{{padding-top:62px}}.brand{{font-size:15px;font-weight:700;letter-spacing:.08em}}.brand i{{display:inline-block;width:12px;height:12px;background:var(--accent);margin-right:10px}}
h1{{font-size:46px;line-height:1.25;letter-spacing:-.04em;margin:40px 0 22px;font-weight:650}}.intro p{{font-size:16px;line-height:1.85;color:var(--muted);max-width:310px}}
button{{margin-top:24px;border:0;background:var(--ink);color:white;padding:14px 24px;font:inherit;cursor:pointer}}button:hover{{background:#474238}}button:focus-visible{{outline:3px solid #c69000;outline-offset:4px}}
.privacy{{margin-top:26px;font-size:12px!important}}.receipt{{background:var(--paper);position:relative;padding:30px 30px 36px;box-shadow:0 16px 36px #5349311a;overflow-wrap:anywhere}}
.receipt::before,.receipt::after{{content:"";position:absolute;left:0;right:0;height:7px;background:linear-gradient(135deg,transparent 5px,var(--paper) 0) 0 0/10px 10px,linear-gradient(-135deg,transparent 5px,var(--paper) 0) 0 0/10px 10px}}
.receipt::before{{top:-6px}}.receipt::after{{bottom:-6px;transform:rotate(180deg)}}.ticket-top{{display:flex;justify-content:space-between;align-items:center;font-size:11px;letter-spacing:.12em;font-weight:700}}
.mark{{display:grid;place-items:center;width:38px;height:38px;border:1px solid var(--ink);font-size:23px;line-height:1;background:var(--accent)}}.ticket-title{{font-size:30px;line-height:1.3;margin:29px 0 10px;letter-spacing:-.02em}}
.meta{{font:11px/1.8 ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--muted)}}.status{{display:inline-block;margin:16px 0 23px;background:#f5e4b5;padding:6px 9px;font-size:11px;line-height:1.5}}
.rule{{border-top:1px dashed var(--rule)}}.food-list{{padding:8px 0;list-style:none;margin:0}}.food-list li{{display:flex;gap:12px;align-items:flex-start;padding:15px 0}}.line-number{{color:#a59d8c;font:11px/1.7 ui-monospace,monospace;margin-top:2px}}
.food{{flex:1;min-width:0}}.food strong{{font-size:14px;line-height:1.65;font-weight:600;display:block}}.food small{{font-size:11px;line-height:1.8;color:var(--muted)}}.qty{{font:13px/2 ui-monospace,monospace;white-space:nowrap}}
.total{{display:flex;align-items:baseline;justify-content:space-between;padding:24px 0 19px}}.total span{{font-size:13px}}.money{{font:600 43px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:-.055em}}.money b{{font-size:23px;margin-right:4px;font-weight:500}}
.nutrition{{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:18px 0 22px}}.nutrition div+div{{border-left:1px solid var(--rule);padding-left:23px}}.nutrition strong{{font:500 23px/1.5 ui-monospace,monospace}}.nutrition small{{display:block;font-size:10px;line-height:1.5;color:var(--muted)}}
.eyebrow{{font-size:10px;letter-spacing:.1em;color:var(--muted)}}.offers{{border-top:1px dashed var(--rule);padding:18px 0 4px}}.offers ul{{padding-left:15px;font-size:11px;line-height:1.8}}
.reason{{font-size:12px;line-height:1.9;margin:17px 0 23px}}.foot{{font-size:10px;line-height:1.8;color:var(--muted)}}.foot p{{margin:8px 0}}.signoff{{text-align:center;padding-top:23px;font:10px/2 ui-monospace,monospace;letter-spacing:.17em}}.store{{font-size:11px;line-height:1.8}}
@media(max-width:760px){{.layout{{display:flex;flex-direction:column;padding:28px 18px 38px;gap:30px;align-items:center}}.intro{{padding:0;width:min(100%,430px)}}h1{{font-size:27px;margin:20px 0 10px}}.intro p{{font-size:13px;margin:6px 0;max-width:none}}button{{padding:10px 16px;font-size:12px;margin-top:14px}}.privacy{{margin-top:12px}}.receipt{{width:min(100%,430px);padding:26px 24px 30px}}.ticket-title{{font-size:27px}}}}
@media print{{@page{{size:A5;margin:12mm}}body{{background:white}}.layout{{display:block;padding:0;margin:0}}.intro{{display:none}}.receipt{{box-shadow:none;width:100%;max-width:430px;margin:auto;break-inside:avoid}}}}
</style></head><body><main class="layout"><aside class="intro"><div class="brand"><i></i>麦麦搭餐</div><h1>这一餐，<br>照你的意思来。</h1><p>想吃什么、预算多少，<br>把选择留给自己，把计算交给工具。</p><button id="print-receipt" type="button">打印 / 保存为 PDF</button><p class="privacy">{'私人详情版，请检查后再分享。' if private else '分享版已隐藏定位与取餐信息。'}<br>{safe(mode_note)}</p></aside>
<article class="receipt" aria-label="配餐小票"><div class="ticket-top"><span>MEAL BUDDY / {public_text(plan_id)}</span><span class="mark" aria-hidden="true">麦</span></div>
<h2 class="ticket-title">{safe(intent)}</h2><div class="meta">{stamp} · {channel} · {safe(label)}</div>{private_line}<div class="status">{public_text(status)}</div>
<div class="rule"></div><ul class="food-list">{''.join(rows)}</ul><div class="rule"></div>
<div class="total"><span>{'示例总额' if report['mode']=='demo' else '核价总额'}</span><strong class="money"><b>¥</b>{total}</strong></div>
<div class="nutrition"><div><strong>{safe(kcal)}</strong><small>估算热量 / kcal</small></div><div><strong>{safe(protein)}</strong><small>估算蛋白质 / g</small></div></div>{offer_section}
<div class="rule"></div><p class="reason">{reason}</p><div class="foot"><p>{safe(missing_note)}</p><p>{safe(notice)}</p></div>
<div class="signoff">ENJOY YOUR OWN CHOICE<br>麦麦搭餐 · 个人配餐小票</div></article></main><script>{script}</script></body></html>'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--private", action="store_true")
    args = parser.parse_args()
    try:
        page = render(read_json(args.input), args.plan, args.private)
        write_text(args.output, page)
        print(str(Path(args.output).resolve()))
    except (PlanError, OSError, KeyError, TypeError) as error:
        message = str(error) if isinstance(error, PlanError) else "读取失败或数据结构不符合契约"
        parser.exit(2, message + "\n")


if __name__ == "__main__":
    main()
