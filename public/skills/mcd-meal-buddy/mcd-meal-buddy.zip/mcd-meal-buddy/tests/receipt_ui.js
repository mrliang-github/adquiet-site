// Development check, run through tests/run_receipt_ui.py.
// Browser space belongs only to this receipt validation task.
const fs = await import("node:fs/promises");
const path = await import("node:path");
const root = globalThis.MCD_SKILL_ROOT;
if (!root) throw new Error("Use tests/run_receipt_ui.py to provide an absolute project path");
const task = await taskSpace(globalThis.MCD_UI_SPACE || "麦麦搭餐 Skill 小票验证");
console.log(JSON.stringify({ spaceId: task.spaceId }));
const page = task.page("p1");
const output = path.join(root, "docs", "previews");
await fs.mkdir(output, { recursive: true });
await page.cdp("Emulation.setDeviceMetricsOverride", { width: 1200, height: 1100, deviceScaleFactor: 1, mobile: false });
await page.goto("file://" + path.join(root, "examples", "receipts", "burger.html"));
console.log(await page.snapshot());
const desktop = await page.evaluate(() => ({
  width: innerWidth, scrollWidth: document.documentElement.scrollWidth,
  title: document.title, hasDemo: document.body.innerText.includes("全部为虚构样例"),
  scripts: document.scripts.length,
}));
if (desktop.scrollWidth > desktop.width || !desktop.hasDemo || desktop.scripts !== 1) {
  throw new Error("Desktop layout or demonstration boundary failed");
}
await page.screenshot({ path: path.join(output, "receipt-desktop.png"), fullPage: true });
await page.evaluate(() => { window.print = () => { window.__printInvoked = true; }; });
await page.click("loc=role:button[name='打印 / 保存为 PDF']");
if (!(await page.evaluate(() => window.__printInvoked === true))) throw new Error("Print button did not execute under CSP");
await page.cdp("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 1, mobile: true });
const mobile = await page.evaluate(() => ({ width: innerWidth, scrollWidth: document.documentElement.scrollWidth,
  cardWidth: document.querySelector(".receipt").getBoundingClientRect().width }));
if (mobile.scrollWidth > mobile.width || mobile.cardWidth > mobile.width) throw new Error("Mobile overflow");
await page.screenshot({ path: path.join(output, "receipt-mobile.png"), fullPage: true });
console.log(JSON.stringify({ desktop, mobile, printButton: "passed" }));
await fs.writeFile(path.join(output, "ui-result.json"), JSON.stringify({ desktop, mobile, printButton: "passed", data: "fictional" }, null, 2));
console.log(await task.finish({ keep: [] }));
