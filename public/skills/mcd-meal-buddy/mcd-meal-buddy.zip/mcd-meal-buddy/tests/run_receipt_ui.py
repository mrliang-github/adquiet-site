"""Pass explicit task paths to Ego's isolated Node runtime; resume after errors."""
import argparse
import json
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--space", type=int, help="Existing task space to resume after an interrupted check")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
prefix = "globalThis.MCD_SKILL_ROOT=" + json.dumps(str(root)) + ";\n"
if args.space is not None:
    prefix += "globalThis.MCD_UI_SPACE=" + str(args.space) + ";\n"
code = prefix + (root / "tests/receipt_ui.js").read_text()
raise SystemExit(subprocess.run(["ego-browser", "nodejs"], input=code, text=True).returncode)
