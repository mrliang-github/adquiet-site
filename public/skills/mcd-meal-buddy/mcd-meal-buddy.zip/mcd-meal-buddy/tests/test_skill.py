import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "examples"))
from meal_plan import PlanError, amount_in_cents, analyze, compare, fingerprint, read_json, write_text
from receipt import render
from sample_factory import make_plan, samples


class MealFlowTests(unittest.TestCase):
    def setUp(self):
        self.doc = samples()["burger"]

    def rejected(self, doc):
        self.assertTrue(analyze(doc)["rejected"])

    def test_burger_meal_total_is_full_quote_and_nutrition_sum(self):
        best = analyze(self.doc)["plans"][0]
        self.assertEqual(best["total_cents"], 2780)
        self.assertEqual(best["nutrition"]["kcal"], 610)
        self.assertEqual(best["nutrition"]["protein_g"], 27)
        self.assertEqual(len(analyze(self.doc)["plans"]), 3)

    def test_new_intent_rejects_regular_food_and_requires_evidence(self):
        self.doc["request"]["intent"] = "new"
        report = analyze(self.doc)
        self.assertEqual([p["id"] for p in report["plans"]], ["C"])
        self.doc["plans"][2]["items"][0].pop("new_evidence")
        self.assertTrue(analyze(self.doc)["needs_relaxation"])

    def test_light_keeps_burger_and_fries_and_rejects_high_calories(self):
        report = analyze(samples()["light"])
        self.assertEqual([p["id"] for p in report["accepted"]], ["A", "B"])
        self.assertEqual(report["plans"][0]["id"], "A")
        self.assertIn("热量", report["rejected"][0]["reason"])

    def test_missing_nutrition_is_partial_and_cannot_pass_hard_cap(self):
        self.doc["plans"] = [self.doc["plans"][0]]
        self.doc["plans"][0]["items"][0]["kcal_per_serving"] = None
        plan = analyze(self.doc)["plans"][0]
        self.assertIsNone(plan["nutrition"]["kcal"])
        self.assertEqual(plan["nutrition"]["known_kcal"], 220)
        self.doc["request"]["max_kcal"] = 2000
        self.assertTrue(analyze(self.doc)["needs_relaxation"])

    def test_repeated_quantities_are_counted_and_required(self):
        plan = make_plan("D", [("BURGER_CHICKEN", 2), ("FRIES_S", 2)], 3400, "双份演示")
        self.doc["plans"] = [plan]
        self.doc["request"]["required"] = [{"kind": "category", "value": "burger", "quantity": 2}]
        self.assertEqual(analyze(self.doc)["plans"][0]["nutrition"]["kcal"], 1220)
        self.doc["request"]["required"][0]["quantity"] = 3
        self.assertTrue(analyze(self.doc)["needs_relaxation"])

    def test_same_parent_combo_with_different_rounds_keeps_all_foods(self):
        plan = self.doc["plans"][0]
        plan["payload"]["items"] = [
            {"productCode": "COMBO", "quantity": 1, "roundList": [{"code": "BURGER_CHICKEN"}]},
            {"productCode": "COMBO", "quantity": 1, "roundList": [{"code": "FRIES_S"}]}]
        plan["quote"]["request_sha256"] = fingerprint(plan["payload"])
        self.assertEqual(analyze(self.doc)["plans"][0]["nutrition"]["kcal"], 610)

    def test_changed_round_or_quantity_invalidates_quote(self):
        self.doc["plans"] = [self.doc["plans"][0]]
        self.doc["plans"][0]["payload"]["items"][0]["quantity"] = 2
        self.assertIn("旧核价", analyze(self.doc)["rejected"][0]["reason"])

    def test_store_and_channel_are_bound(self):
        for key, value in (("storeCode", "OTHER"), ("orderType", 2)):
            doc = copy.deepcopy(self.doc)
            doc["plans"] = [doc["plans"][0]]
            doc["plans"][0]["payload"][key] = value
            doc["plans"][0]["quote"]["request_sha256"] = fingerprint(doc["plans"][0]["payload"])
            self.assertTrue(analyze(doc)["needs_relaxation"])

    def test_delivery_total_includes_fee_no_double_addition(self):
        self.doc["context"].update(dining_mode="delivery", address_confirmed=True)
        self.doc["plans"] = [self.doc["plans"][0]]
        plan = self.doc["plans"][0]
        plan["payload"].update(orderType=2, beType=2)
        plan["quote"]["request_sha256"] = fingerprint(plan["payload"])
        plan["quote"]["response"]["data"]["demoPayable"] = 3780
        self.assertTrue(analyze(self.doc)["needs_relaxation"])
        self.doc["request"]["budget_cents"] = 4000
        self.assertEqual(analyze(self.doc)["plans"][0]["total_cents"], 3780)

    def test_money_units_are_explicit_and_precise(self):
        self.assertEqual(amount_in_cents("27.80", "yuan"), 2780)
        self.assertEqual(amount_in_cents(2780, "fen"), 2780)
        for value, unit in (("27.801", "yuan"), (2, None), (True, "fen"), ("NaN", "yuan")):
            with self.assertRaises(PlanError):
                amount_in_cents(value, unit)

    def test_failed_expired_and_demo_quotes_are_not_live_recommendations(self):
        for change in ("failed", "expired", "mode"):
            doc = copy.deepcopy(self.doc)
            doc["plans"] = [doc["plans"][0]]
            quote = doc["plans"][0]["quote"]
            if change == "failed": quote["response"]["success"] = False
            if change == "expired": quote["captured_at"] = "2026-10-13T11:30:00+08:00"
            if change == "mode": doc["mode"] = "live"
            self.assertTrue(analyze(doc)["needs_relaxation"])

    def test_equivalent_foods_keep_cheapest_buying_path(self):
        same = copy.deepcopy(self.doc["plans"][0])
        same["id"] = "D"
        same["quote"]["response"]["data"]["demoPayable"] = 2500
        self.doc["plans"].append(same)
        report = analyze(self.doc)
        self.assertEqual(report["plans"][0]["id"], "D")
        self.assertNotIn("A", [p["id"] for p in report["plans"]])

    def test_compare_reports_actual_swap_and_nullable_calorie_delta(self):
        before = analyze(self.doc)
        other = samples()["light"]
        after = analyze(other)
        diff = compare(before, "B", after, "A")
        self.assertEqual(diff["price_delta_cents"], -200)
        self.assertEqual(diff["kcal_delta"], 55)
        self.assertTrue(diff["changes"])
        other["request"].pop("max_kcal")
        other["plans"][0]["items"][0]["kcal_per_serving"] = None
        self.assertIsNone(compare(before, "B", analyze(other), "A")["kcal_delta"])

    def test_hard_budget_no_solution_does_not_relax_it(self):
        self.doc["request"]["budget_cents"] = 100
        report = analyze(self.doc)
        self.assertEqual(report["plans"], [])
        self.assertTrue(report["needs_relaxation"])

    def test_excluded_foods_and_bad_numeric_data(self):
        self.doc["request"]["excluded_food_ids"] = ["FRIES_S"]
        self.assertEqual([p["id"] for p in analyze(self.doc)["plans"]], ["B"])
        self.doc["plans"][1]["items"][0]["kcal_per_serving"] = float("nan")
        self.assertTrue(analyze(self.doc)["needs_relaxation"])


class ReceiptTests(unittest.TestCase):
    def setUp(self):
        self.doc = samples()["burger"]

    def test_untrusted_strings_are_escaped(self):
        self.doc["plans"][0]["items"][0]["name"] = '<img src=x onerror="window.injected=1">'
        self.doc["plans"][0]["offers"] = ['</style><script>alert(1)</script>']
        page = render(self.doc, "A")
        self.assertNotIn('<img src=x', page)
        self.assertNotIn('<script>alert(1)', page)
        self.assertIn('&lt;img', page)
        self.assertIn('Content-Security-Policy', page)
        self.assertEqual(page.count('<script>'), 1)

    def test_share_page_omits_private_fields_and_user_reason(self):
        self.doc["context"]["store_name"] = "PRIVATE_STORE_MARKER"
        self.doc["context"]["address"] = "PRIVATE_ADDRESS_MARKER"
        self.doc["context"]["phone"] = "13800138000"
        self.doc["plans"][0]["reason"] = "PRIVATE_USER_REASON"
        self.doc["plans"][0]["payload"]["addressId"] = "PRIVATE_ADDRESS_ID"
        self.doc["plans"][0]["quote"]["request_sha256"] = fingerprint(self.doc["plans"][0]["payload"])
        self.doc["order"] = {"order_id": "PRIVATE_ORDER_ID", "pickup_code": "PRIVATE_PICKUP_CODE"}
        page = render(self.doc, "A")
        for marker in ("PRIVATE_", "13800138000"):
            self.assertNotIn(marker, page)
        private = render(self.doc, "A", private=True)
        self.assertIn("PRIVATE_STORE_MARKER", private)
        self.assertNotIn("PRIVATE_ADDRESS_ID", private)

    def test_demo_cannot_be_presented_as_a_paid_real_order(self):
        self.doc["order"] = {"status_text": "订单已支付"}
        page = render(self.doc, "A")
        self.assertIn("演示 · 配餐预览", page)
        self.assertNotIn("订单已支付", page)

    def test_live_status_must_be_bound_to_plan_and_query_order(self):
        self.doc["mode"] = "live"
        for plan in self.doc["plans"]: plan["quote"]["source"] = "calculate-price"
        self.doc["order"] = {"plan_id": "A", "source": "query-order", "observed_at": self.doc["context"]["as_of"],
                             "request_sha256": "invalid", "status_text": "待支付"}
        with self.assertRaises(PlanError): render(self.doc, "A")
        self.doc["order"]["request_sha256"] = self.doc["plans"][0]["quote"]["request_sha256"]
        self.assertIn("订单状态 · 待支付", render(self.doc, "A"))

    def test_missing_nutrition_is_visible_on_receipt(self):
        self.doc["plans"][0]["items"][0]["kcal_per_serving"] = None
        page = render(self.doc, "A")
        self.assertIn("220 + ?", page)
        self.assertIn("无法确认整餐热量", page)


class LocalFileTests(unittest.TestCase):
    def test_credentials_are_rejected_and_output_file_is_private(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "case.json"
            write_text(path, json.dumps({"token": "TEST_SECRET_SENTINEL"}))
            with self.assertRaises(PlanError): read_json(path)
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            link = Path(directory) / "link.json"
            link.symlink_to(path)
            with self.assertRaises(PlanError): write_text(link, "overwrite")

    def test_cli_runs_three_fixtures_and_generates_receipt(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory)
            for name, doc in samples().items():
                source = target / (name + ".json")
                output = target / (name + "-report.json")
                write_text(source, json.dumps(doc))
                run = subprocess.run([sys.executable, str(ROOT / "scripts/meal_plan.py"), "analyze", str(source), "--output", str(output)], capture_output=True, text=True)
                self.assertEqual(run.returncode, 0, run.stderr)
                report = read_json(output)
                self.assertTrue(report["plans"])
                receipt = target / (name + ".html")
                run = subprocess.run([sys.executable, str(ROOT / "scripts/receipt.py"), str(source), "--plan", report["plans"][0]["id"], "--output", str(receipt)], capture_output=True, text=True)
                self.assertEqual(run.returncode, 0, run.stderr)
                self.assertIn("全部为虚构样例", receipt.read_text())


if __name__ == "__main__":
    unittest.main()
